package com.vividsolutions.jts.index;

/**
 * A visitor for nodes and items in an index.
 *
 * @version 1.5
 */

public interface IndexVisitor {
  void visitItem(Object item);
}
