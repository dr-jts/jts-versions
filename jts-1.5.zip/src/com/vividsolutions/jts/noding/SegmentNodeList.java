


/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.noding;

import java.io.PrintStream;
import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.Debug;

/**
 * A list of the {@link SegmentNode}s present along a noded {@link SegmentString}.
 *
 * @version 1.5
 */
public class SegmentNodeList
{
  // a List of SegmentNodes
  //List list = new ArrayList();    // more efficient to use a LinkedList, but ArrayList is easier for debugging
  private Map nodeMap = new TreeMap();
  private SegmentString edge;  // the parent edge
  private List sortedNodes;

  public SegmentNodeList(SegmentString edge)
  {
    this.edge = edge;
  }

  /**
   * Adds an intersection into the list, if it isn't already there.
   * The input segmentIndex and dist are expected to be normalized.
   * @return the SegmentIntersection found or added
   */
  public SegmentNode add(Coordinate intPt, int segmentIndex, double dist)
  {
    SegmentNode eiNew = new SegmentNode(intPt, segmentIndex, dist);
    Object obj = nodeMap.get(eiNew);
    SegmentNode ei = (SegmentNode) nodeMap.get(eiNew);
    if (ei != null) {
      return ei;
    }
    nodeMap.put(eiNew, eiNew);
    return eiNew;
  }
  /**
   * Adds an intersection into the list, if it isn't already there.
   * The input segmentIndex and dist are expected to be normalized.
   * @return the SegmentIntersection found or added
   */
  /*
  public SegmentNode OLDadd(Coordinate intPt, int segmentIndex, double dist)
  {
//Debug.println("adding edgeInt " + intPt + " " + segmentIndex + " " + dist);
    ListIterator insertIt = list.listIterator();
    boolean isInList = findInsertionPoint(segmentIndex, dist, insertIt);
    SegmentNode ei;
    if (! isInList) {
      ei = new SegmentNode(intPt, segmentIndex, dist);
      insertIt.add(ei);
    }
    else
      ei = (SegmentNode) insertIt.next();
    return ei;
  }
  /**
   * returns an iterator of SegmentNodes
   */
  public Iterator iterator() { return nodeMap.values().iterator(); }
/*
  public boolean isEmpty()
  {
    Iterator it = list.iterator();
    return ! it.hasNext();
  }
  */
  /**
   * This routine searches the list for the insertion point for the given intersection
   * (which must be in normalized form).
   * The intersection point may already be in the list - in this case, the intersection
   * is not inserted.
   * If the intersection is new, it is inserted into the list.
   * The insertIt iterator is left pointing at the correct place
   * to insert the intersection, if the intersection was not found.
   *
   * @return true if this intersection is already in the list
   */
  /*
  boolean findInsertionPoint(int segmentIndex, double dist, ListIterator insertIt)
  {
    // The insertIt position trails the findIt position by one
    ListIterator findIt = list.listIterator();
    boolean found = false;
    while (findIt.hasNext()) {
      SegmentNode ei = (SegmentNode) findIt.next();
      int compare = ei.compare(segmentIndex, dist);

      // intersection found - insertIt.next() will retrieve it
      if (compare == 0) return true;

      // this ei is past the intersection location, so intersection was not found
      if (compare > 0) return false;

      // this ei was before the intersection point, so move to next
      insertIt.next();
    }
    return false;
  }

  public boolean isIntersection(Coordinate pt)
  {
    for (Iterator it = list.iterator(); it.hasNext(); ) {
      SegmentNode ei = (SegmentNode) it.next();
      if (ei.coord.equals(pt))
       return true;
    }
    return false;
  }
  */
  /**
   * Adds entries for the first and last points of the edge to the list
   */
  public void addEndpoints()
  {
    int maxSegIndex = edge.size() - 1;
    add(edge.getCoordinate(0), 0, 0.0);
    add(edge.getCoordinate(maxSegIndex), maxSegIndex, 0.0);
  }

  /**
   * Creates new edges for all the edges that the intersections in this
   * list split the parent edge into.
   * Adds the edges to the input list (this is so a single list
   * can be used to accumulate all split edges for a Geometry).
   */
  public void addSplitEdges(Collection edgeList)
  {
    // testingOnly
    List testingSplitEdges = new ArrayList();
    // ensure that the list has entries for the first and last point of the edge
    addEndpoints();

    Iterator it = iterator();
    // there should always be at least two entries in the list
    SegmentNode eiPrev = (SegmentNode) it.next();
    while (it.hasNext()) {
      SegmentNode ei = (SegmentNode) it.next();
      SegmentString newEdge = createSplitEdge(eiPrev, ei);
      edgeList.add(newEdge);

      testingSplitEdges.add(newEdge);

      eiPrev = ei;
    }
    //checkSplitEdgesCorrectness(testingSplitEdges);
  }

  private void checkSplitEdgesCorrectness(List splitEdges)
  {
    Coordinate[] edgePts = edge.getCoordinates();

    // check that first and last points of split edges are same as endpoints of edge
    SegmentString split0 = (SegmentString) splitEdges.get(0);
    Coordinate pt0 = split0.getCoordinate(0);
    if (! pt0.equals(edgePts[0]))
      throw new RuntimeException("bad split edge start point at " + pt0);

    SegmentString splitn = (SegmentString) splitEdges.get(splitEdges.size() - 1);
    Coordinate[] splitnPts = splitn.getCoordinates();
    Coordinate ptn = splitnPts[splitnPts.length - 1];
    if (! ptn.equals(edgePts[edgePts.length - 1]))
      throw new RuntimeException("bad split edge end point at " + ptn);

  }
  /**
   * Create a new "split edge" with the section of points between
   * (and including) the two intersections.
   * The label for the new edge is the same as the label for the parent edge.
   */
  SegmentString createSplitEdge(SegmentNode ei0, SegmentNode ei1)
  {
//Debug.print("\ncreateSplitEdge"); Debug.print(ei0); Debug.print(ei1);
    int npts = ei1.segmentIndex - ei0.segmentIndex + 2;

    Coordinate lastSegStartPt = edge.getCoordinate(ei1.segmentIndex);
    // if the last intersection point is not equal to the its segment start pt,
    // add it to the points list as well.
    // (This check is needed because the distance metric is not totally reliable!)
    // The check for point equality is 2D only - Z values are ignored
    boolean useIntPt1 = ei1.dist > 0.0 || ! ei1.coord.equals2D(lastSegStartPt);
    if (! useIntPt1) {
      npts--;
    }

    Coordinate[] pts = new Coordinate[npts];
    int ipt = 0;
    pts[ipt++] = new Coordinate(ei0.coord);
    for (int i = ei0.segmentIndex + 1; i <= ei1.segmentIndex; i++) {
      pts[ipt++] = edge.getCoordinate(i);
    }
    if (useIntPt1) pts[ipt] = ei1.coord;
    return new SegmentString(pts, edge.getContext());
  }
/*
  public Coordinate[] getCoordinates()
  {
    List pts = new ArrayList();
    Iterator it = list.iterator();
    int nextIndex = 0;
    while (it.hasNext()) {
      SegmentNode ei = (SegmentNode) it.next();

      // add points up to this intersection

      for (int i = nextIndex; i <= ei.segmentIndex; i++) {
        pts.add(edge.getCoordinate(i));
      }
      nextIndex = ei.segmentIndex + 1;
      if (ei.dist > 0.0) pts.add(ei.coord);
    }
    // add remaining edge coordinates, if any
    for (int i = nextIndex; i < edge.getCoordinates().length; i++) {
      pts.add(edge.getCoordinate(i));
    }
    return CoordinateArrays.toCoordinateArray(pts);
  }
*/
  public void print(PrintStream out)
  {
    out.println("Intersections:");
    for (Iterator it = iterator(); it.hasNext(); ) {
      SegmentNode ei = (SegmentNode) it.next();
      ei.print(out);
    }
  }
}
