/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import java.io.Serializable;

import com.vividsolutions.jts.util.Assert;


/**
 * A lightweight class used to store coordinates
 * on the 2-dimensional Cartesian plane.
 *  It is distinct from <code>Point</code>, which is a subclass of <code>Geometry</code>
 *  . Unlike objects of type <code>Point</code> (which contain additional
 *  information such as an envelope, a precision model, and spatial reference
 *  system information), a <code>Coordinate</code> only contains ordinate values
 *  and accessor methods. <P>
 *
 *  <code>Coordinate</code>s are two-dimensional points, with an additional
 *  z-ordinate. JTS does not support any operations on the z-ordinate except
 *  the basic accessor functions. Constructed coordinates will have a
 *  z-ordinate of <code>NaN</code>.  The standard comparison functions will ignore
 *  the z-ordinate.
 *
 *@version 1.4.0
 */
public class Coordinate implements Comparable, Cloneable, Serializable {
    /**
     *  The x-coordinate.
     */
    public double x;
    /**
     *  The y-coordinate.
     */
    public double y;
    /**
     *  The z-coordinate.
     */
    public double z;

    /**
     *  Constructs a <code>Coordinate</code> at (x,y,z).
     *
     *@param  x  the x-value
     *@param  y  the y-value
     *@param  z  the z-value
     */
    public Coordinate(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     *  Constructs a <code>Coordinate</code> at (0,0,NaN).
     */
    public Coordinate() {
        this(0.0, 0.0);
    }

    /**
     *  Constructs a <code>Coordinate</code> having the same (x,y,z) values as
     *  <code>other</code>.
     *
     *@param  c  the <code>Coordinate</code> to copy.
     */
    public Coordinate(Coordinate c) {
        this(c.x, c.y, c.z);
    }

    /**
     *  Constructs a <code>Coordinate</code> at (x,y,NaN).
     *
     *@param  x  the x-value
     *@param  y  the y-value
     */
    public Coordinate(double x, double y) {
        this(x, y, Double.NaN);
    }



    /**
     *  Sets this <code>Coordinate</code>s (x,y,z) values to that of <code>other</code>
     *  .
     *
     *@param  other  the <code>Coordinate</code> to copy
     */
    public void setCoordinate(Coordinate other) {
        x = other.x;
        y = other.y;
        z = other.z;
    }

    /**
     *  Returns whether the planar projections of the two <code>Coordinate</code>s
     *  are equal.
     *
     *@param  other  a <code>Coordinate</code> with which to do the 2D comparison.
     *@return        <code>true</code> if the x- and y-coordinates are equal; the
     *      z-coordinates do not have to be equal.
     */
    public boolean equals2D(Coordinate other) {
        if (x != other.x) {
            return false;
        }

        if (y != other.y) {
            return false;
        }

        return true;
    }

    /**
     *  Returns <code>true</code> if <code>other</code> has the same values for
     *  the x and y ordinates.
     *  Since Coordinates are 2.5D, this routine ignores the z value when making the comparison.
     *
     *@param  other  a <code>Coordinate</code> with which to do the comparison.
     *@return        <code>true</code> if <code>other</code> is a <code>Coordinate</code>
     *      with the same values for the x and y ordinates.
     */
    public boolean equals(Object other) {
        if (!(other instanceof Coordinate)) {
            return false;
        }
        return equals2D((Coordinate) other);
    }

    /**
     *  Compares this object with the specified object for order.
     *  Since Coordinates are 2.5D, this routine ignores the z value when making the comparison.
     *  Returns
     *  <UL>
     *    <LI> -1 : this.x < other.x || ((this.x == other.x) && (this.y <
     *    other.y))
     *    <LI> 0 : this.x == other.x && this.y = other.y
     *    <LI> 1 : this.x > other.x || ((this.x == other.x) && (this.y > other.y))
     *
     *  </UL>
     *
     *
     *@param  o  the <code>Coordinate</code> with which this <code>Coordinate</code>
     *      is being compared
     *@return    a negative integer, zero, or a positive integer as this <code>Coordinate</code>
     *      is less than, equal to, or greater than the specified <code>Coordinate</code>
     */
    public int compareTo(Object o) {
        Coordinate other = (Coordinate) o;

        if (x < other.x) {
            return -1;
        }

        if (x > other.x) {
            return 1;
        }

        if (y < other.y) {
            return -1;
        }

        if (y > other.y) {
            return 1;
        }

        return 0;
    }

    /**
     *  Returns <code>true</code> if <code>other</code> has the same values for x,
     *  y and z.
     *
     *@param  other  a <code>Coordinate</code> with which to do the 3D comparison.
     *@return        <code>true</code> if <code>other</code> is a <code>Coordinate</code>
     *      with the same values for x, y and z.
     */
    public boolean equals3D(Coordinate other) {
        return (x == other.x) && (y == other.y) &&
        ((z == other.z) ||
        (Double.isNaN(z) && Double.isNaN(other.z)));
    }

    /**
     *  Returns a <code>String</code> of the form <I>(x,y,z)</I> .
     *
     *@return    a <code>String</code> of the form <I>(x,y,z)</I>
     */
    public String toString() {
        return "(" + x + ", " + y + ", " + z + ")";
    }

    public Object clone() {
        try {
            Coordinate coord = (Coordinate) super.clone();

            return coord; // return the clone
        } catch (CloneNotSupportedException e) {
            Assert.shouldNeverReachHere(
                "this shouldn't happen because this class is Cloneable");

            return null;
        }
    }

    /**
     * "Fixes" this Coordinate to the PrecisionModel grid.
     */

    /*
       public void makePrecise(PrecisionModel precisionModel)
       {
         x = precisionModel.makePrecise(x);
         y = precisionModel.makePrecise(y);
       }
     */
    public double distance(Coordinate p) {
        double dx = x - p.x;
        double dy = y - p.y;

        return Math.sqrt(dx * dx + dy * dy);
    }

    public int hashCode() {
        //Algorithm from Effective Java by Joshua Bloch [Jon Aquino]
        int result = 17;
        result = 37 * result + hashCode(x);
        result = 37 * result + hashCode(y);
        return result;
    }

    /**
     * Returns a hash code for a double value, using the algorithm from
     * Joshua Bloch's book <i>Effective Java"</i>
     */
    public static int hashCode(double x) {
        long f = Double.doubleToLongBits(x);
        return (int)(f^(f>>>32));
    }
}
