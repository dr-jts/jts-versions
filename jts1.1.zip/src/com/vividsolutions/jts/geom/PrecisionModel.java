/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;


/**
 *  Converts a coordinate to and from a "precise" coordinate; that is, one whose
 *  precision is known exactly. In other words, specifies the grid of allowable
 *  points for all <code>Geometry</code>s. <P>
 *
 *  Vertices are assumed to be precise in JTS. That is, the coordinates of
 *  vertices are assumed to be rounded to the defined precision model. Input
 *  routines will be responsible for rounding coordinates to the precision model
 *  before creating JTS structures. Non-constructive internal operations will
 *  assume that coordinates are rounded to the precision model. <P>
 *
 *  JTS methods will not handle inputs with different precision models. <P>
 *
 *  The Precision Model will be specified by a scale factor and an offset point.
 *  The scale factor specifies how many JTS units represent one world unit.
 *  World coordinates are mapped to JTS coordinates according to the following
 *  equations:
 *  <UL>
 *    <LI> jtsPt.x = truncate( (inputPt.x - offset.x) * scale )
 *    <LI> jtsPt.y = truncate( (inputPt.y - offset.y) * scale )
 *  </UL>
 *  Scaled coordinates will be represented internally as integral
 *  double-precision values. This is known as the "precise internal
 *  representation". Since Java uses the IEEE-394 floating point standard, this
 *  provides 53 bits of precision. (Thus the maximum precisely representable
 *  integer is 9,007,199,254,740,992).
 *
 *@version 1.1
 */
public class PrecisionModel {
  /**
   * The types of Precision Model which could be implemented.
   * (Note that JTS does not necessarily support all of these.)
   */
   /**
    * Fixed Precision implies that coordinates have a fixed number of decimal places
    */
  public final static int FIXED     = 1;
  /**
   * Floating precision corresponds to the usual notion of floating-point representation.
   */
  public final static int FLOATING  = 2;

  /**
   *  The maximum precise value representable in a double. Since IEE754
   *  double-precision numbers allow 53 bits of mantissa, the value is equal to
   *  2^53 - 1.
   */
  public final static double maximumPreciseValue = 9007199254740992.0;
  /**
   * This method "fixes" an ordinate value to
   * the PrecisionModel grid.
   */
  public static double makePrecise(double val)
  {
    return Math.rint(val);
    //return (val >= 0.0) ? Math.floor(val) : - Math.floor(-val);
    /*
     * Other options:
     * - Math.floor(a + 0.5d);
     * - Math.floor(a);
     * -  (val >= 0.0) ? Math.floor(val) : - Math.floor(-val);
     */
  }

  /**
   * The type of PrecisionModel this represents.
   */
  private int modelType = 0;
  /**
   * Amount by which to multiply a coordinate after subtracting the offset,
   * to obtain a precise coordinate.
   * If scale is 0, this PrecisionModel represents a floating precision model.
   * Coordinates are left with the implicit precision of the
   * floating-point representation.
   */
  private double scale;
  /**
   *  Amount by which to subtract the x-coordinate before multiplying by the
   *  scale, to obtain a precise coordinate.
   */
  private double offsetX;
  /**
   *  Amount by which to subtract the y-coordinate before multiplying by the
   *  scale, to obtain a precise coordinate.
   */
  private double offsetY;

  /**
   *  Creates a <code>PrecisionModel</code> that specifies Floating precision.
   *
   */
  public PrecisionModel() {
    // default is floating precision
    modelType = FLOATING;
  }

  /**
   *  Creates a <code>PrecisionModel</code> that specifies Fixed precision.
   *  Fixed-precision coordinates are represented as precise internal coordinates,
   *  which are integers stored in double-precision.
   *  Input coordinates are transformed into precise internal coordinates
   *  according to the given scale, x-offset and y-offset.
   *
   *@param  scale    amount by which to multiply a coordinate after subtracting
   *      the offset, to obtain a precise coordinate
   *@param  offsetX  amount by which to subtract the x-coordinate before
   *      multiplying by the scale, to obtain a precise coordinate.
   *@param  offsetY  amount by which to subtract the y-coordinate before
   *      multiplying by the scale, to obtain a precise coordinate.
   */
  public PrecisionModel(double scale, double offsetX, double offsetY) {
    modelType = FIXED;
    this.scale = scale;
    this.offsetX = offsetX;
    this.offsetY = offsetY;
  }
  /**
   *  Copy constructor to create a new <code>PrecisionModel</code>
   *  from an existing one.
   */
  public PrecisionModel(PrecisionModel pm) {
    modelType = pm.modelType;
    scale = pm.scale;
    offsetX = pm.offsetX;
    offsetY = pm.offsetY;
  }


  public boolean isFloating()
  {
    return modelType == FLOATING;
  }
  /**
   *  Returns the multiplying factor used to obtain a precise coordinate.
   *
   *@return    the amount by which to multiply a coordinate after subtracting
   *      the offset
   */
  public double getScale() {
    return scale;
  }

  /**
   *  Returns the x-offset used to obtain a precise coordinate.
   *
   *@return    the amount by which to subtract the x-coordinate before
   *      multiplying by the scale
   */
  public double getOffsetX() {
    return offsetX;
  }

  /**
   *  Returns the y-offset used to obtain a precise coordinate.
   *
   *@return    the amount by which to subtract the y-coordinate before
   *      multiplying by the scale
   */
  public double getOffsetY() {
    return offsetY;
  }

  /**
   *  Sets <code>internal</code> to the precise representation of <code>external</code>
   *  .
   *
   * @param external the original coordinate
   * @param internal the coordinate whose values will be changed to the
   *                 precise representation of <code>external</code>
   */
  public void toInternal (Coordinate external, Coordinate internal) {
    if (isFloating()) {
      internal.x = external.x;
      internal.y = external.y;
    }
    else {
      internal.x = makePrecise((external.x - offsetX)*scale);
      internal.y = makePrecise((external.y - offsetY)*scale);
    }
    internal.z = external.z;
  }

  /**
   *  Returns the precise representation of <code>external</code>.
   *
   *@param  external  the original coordinate
   *@return           the coordinate whose values will be changed to the precise
   *      representation of <code>external</code>
   */
  public Coordinate toInternal(Coordinate external) {
    Coordinate internal = new Coordinate();
    toInternal(external, internal);
    return internal;
  }

  /**
   *  Returns the external representation of <code>internal</code>.
   *
   *@param  internal  the original coordinate
   *@return           the coordinate whose values will be changed to the
   *      external representation of <code>internal</code>
   */
  public Coordinate toExternal(Coordinate internal) {
    Coordinate external = new Coordinate();
    toExternal(internal, external);
    return external;
  }

  /**
   *  Sets <code>external</code> to the external representation of <code>internal</code>
   *  .
   *
   *@param  internal  the original coordinate
   *@param  external  the coordinate whose values will be changed to the
   *      external representation of <code>internal</code>
   */
  public void toExternal(Coordinate internal, Coordinate external) {
    if (isFloating()) {
      external.x = internal.x;
      external.y = internal.y;
    }
    else {
      external.x = (internal.x / scale) + offsetX;
      external.y = (internal.y / scale) + offsetY;
    }
    external.z = internal.z;
  }

  public String toString()
  {
    String description;
    if (isFloating()) {
      description = "Floating";
    }
    else {
      description = "Fixed ( Scale = " + getScale();
      description += "   Offset: X = " + getOffsetX();
      description += ", Y = " + getOffsetY();
      description += " )";
    }
    return description;
  }
  public boolean equals(Object other) {
    if (! (other instanceof PrecisionModel)) {
      return false;
    }
    PrecisionModel otherPrecisionModel = (PrecisionModel) other;
    return modelType == otherPrecisionModel.modelType
        && offsetX == otherPrecisionModel.offsetX
        && offsetY == otherPrecisionModel.offsetY
        && scale == otherPrecisionModel.scale;
  }
}


