/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom.sfs;

import com.vividsolutions.jts.geom.*;

/**
 *  A closed, simple <code>LineString</code>. Consecutive points are not allowed
 *  to be equal. <P>
 *
 *  <code>LinearRing</code>s are the fundamental building block for <code>Polygon</code>
 *  s. <code>LinearRing</code>s may not be degenerate; that is, a <code>LinearRing</code>
 *  must have at least 3 points. Other non-degeneracy criteria are implied by
 *  the requirement that <code>LinearRings</code> be simple. For instance, not
 *  all the points may be collinear. The SFS does not specify a requirement on
 *  the orientation of a <code>LinearRing</code>, and JTS follows this by
 *  allowing them to be oriented either clockwise or counter-clockwise. <P>
 *
 *  If the <code>LinearRing</code> is empty, <code>isClosed</code> and <code>isRing</code>
 *  return <code>true</code>.
 *
 *@version 1.1
 */
public interface SFSLinearRing extends SFSLineString {
}


