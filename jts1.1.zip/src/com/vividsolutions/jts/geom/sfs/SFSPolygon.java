/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom.sfs;

import com.vividsolutions.jts.geom.*;

/**
 *  A simple, planar <code>Surface</code> bounded by one exterior <code>LinearRing</code>
 *  (the "shell") and zero or more interior <code>LinearRing</code>s (the
 *  "holes"). <P>
 *
 *  The shell and holes of a <code>Polygon</code> are <code>LinearRing</code>s.
 *  The SFS definition of <code>Polygon</code> has the following implications:
 *
 *  <UL>
 *    <LI> The shell and holes cannot self-intersect
 *    <LI> Holes can touch the shell or another hole at a single point only.
 *    This means that holes cannot intersect one another at multiple points or
 *    in a line segment.
 *    <LI> Polygon interiors must be connected
 *    <LI> There is no requirement that a point where a hole touches the shell
 *    be a vertex.
 *  </UL>
 *  Note that the SFS definition of <code>Polygon</code> differs from that in
 *  some other commonly used spatial models. For instance, the ESRI ArcSDE
 *  spatial model allows shells to self-intersect at vertices, but does not
 *  allow holes to touch the shell. The SFS and the ArcSDE model are equivalent
 *  in the sense that they allow describing exactly the same set of areas.
 *  However, they may require different polygon structures to describe the same
 *  area. <P>
 *
 *  <code>Polygon</code>s do not have cut lines, spikes or punctures. <P>
 *
 *  Two boundary rings may intersect at one point at most. <P>
 *
 *  Empty <code>Polygons</code> may not contain holes. <P>
 *
 *  Since the shell and holes of <code>Polygons</code> are <code>LinearRing</code>
 *  s, there is no requirement on their orientation. They may be oriented either
 *  clockwise or counterclockwise. <P>
 *
 *  For a precise definition of a polygon, see the <A
 *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
 *  Specification for SQL</A> .
 *
 *@version 1.1
 */
public interface SFSPolygon extends SFSSurface {

  /**
   *  Returns the shell.
   *
   *@return    the exterior boundary, or <code>null</code> if this <code>Polygon</code>
   *      is the empty geometry.
   */
  public LineString getExteriorRing();

  /**
   *  Returns the number of holes.
   *
   *@return    the number of interior boundaries.
   */
  public int getNumInteriorRing();

  /**
   *  Returns the hole at the given index.
   *
   *@param  n  the index of the interior boundary to return (n = 0, 1, 2, ...)
   *@return    the Nth interior <code>LinearRing</code> in this <code>Polygon</code>
   */
  public LineString getInteriorRingN(int n);
}

