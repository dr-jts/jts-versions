/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.util.Assert;
import java.util.*;

/**
 *  Basic implementation of <code>GeometryFactory</code>.
 *
 *@version 1.1
 */
public class GeometryFactory {
  /**
   *  The specification of the grid of allowable points for all <code>Geometry</code>
   *  s created by this <code>GeometryFactory</code>
   */
  private PrecisionModel precisionModel;
  /**
   *  The ID of the Spatial Reference System used by all <code>Geometry</code>s.
   *  created by this <code>GeometryFactory</code>
   */
  private int SRID;

  /**
   *  Creates a <code>GeometryFactory</code> that creates <code>Geometry</code>
   *  s using the given <code>precisionModel</code> and <code>SRID</code>.
   *
   *@param  precisionModel  the specification of the grid of allowable points
   *      for <code>Geometry</code>s created by this <code>GeometryFactory</code>
   *@param  SRID            the ID of the Spatial Reference System used by
   *      <code>Geometry</code> created by this <code>GeometryFactory</code>
   */
  public GeometryFactory(PrecisionModel precisionModel, int SRID) {
    this.precisionModel = precisionModel;
    this.SRID = SRID;
  }

  /**
   *  Creates a <code>GeometryFactoryImpl</code> that creates <code>Geometry</code>s
   *  using Floating <code>precisionModel</code> and an <code>SRID</code> of 0.
   */
  public GeometryFactory() {
    this(new PrecisionModel(), 0);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  points  the <code>List</code> to convert
   *@return         the <code>List</code> in array format
   */
  public static Point[] toPointArray(List points) {
    Point[] pointArray = new Point[points.size()];
    return (Point[]) points.toArray(pointArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  geometrys  the list of <code>Geometrys</code> to convert
   *@return            the <code>List</code> in array format
   */
  public static Geometry[] toGeometryArray(List geometrys) {
    Geometry[] geometryArray = new Geometry[geometrys.size()];
    return (Geometry[]) geometrys.toArray(geometryArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  linearRings  the <code>List</code> to convert
   *@return              the <code>List</code> in array format
   */
  public static LinearRing[] toLinearRingArray(List linearRings) {
    LinearRing[] linearRingArray = new LinearRing[linearRings.size()];
    return (LinearRing[]) linearRings.toArray(linearRingArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  lineStrings  the <code>List</code> to convert
   *@return              the <code>List</code> in array format
   */
  public static LineString[] toLineStringArray(List lineStrings) {
    LineString[] lineStringArray = new LineString[lineStrings.size()];
    return (LineString[]) lineStrings.toArray(lineStringArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  polygons  the <code>List</code> to convert
   *@return           the <code>List</code> in array format
   */
  public static Polygon[] toPolygonArray(List polygons) {
    Polygon[] polygonArray = new Polygon[polygons.size()];
    return (Polygon[]) polygons.toArray(polygonArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  multiPolygons  the <code>List</code> to convert
   *@return                the <code>List</code> in array format
   */
  public static MultiPolygon[] toMultiPolygonArray(List multiPolygons) {
    MultiPolygon[] multiPolygonArray = new MultiPolygon[multiPolygons.size()];
    return (MultiPolygon[]) multiPolygons.toArray(multiPolygonArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  multiLineStrings  the <code>List</code> to convert
   *@return                   the <code>List</code> in array format
   */
  public static MultiLineString[] toMultiLineStringArray(List multiLineStrings) {
    MultiLineString[] multiLineStringArray = new MultiLineString[multiLineStrings.size()];
    return (MultiLineString[]) multiLineStrings.toArray(multiLineStringArray);
  }

  /**
   *  Converts the <code>List</code> to an array.
   *
   *@param  multiPoints  the <code>List</code> to convert
   *@return              the <code>List</code> in array format
   */
  public static MultiPoint[] toMultiPointArray(List multiPoints) {
    MultiPoint[] multiPointArray = new MultiPoint[multiPoints.size()];
    return (MultiPoint[]) multiPoints.toArray(multiPointArray);
  }

  /**
   *  If the <code>Envelope</code> is a null <code>Envelope</code>, returns an
   *  empty <code>Point</code>. If the <code>Envelope</code> is a point, returns
   *  a non-empty <code>Point</code>. If the <code>Envelope</code> is a
   *  rectangle, returns a <code>Polygon</code> whose points are (minx, miny),
   *  (maxx, miny), (maxx, maxy), (minx, maxy), (minx, miny).
   *
   *@param  envelope        the <code>Envelope</code> to convert to a <code>Geometry</code>
   *@param  precisionModel  the specification of the grid of allowable points
   *      for the new <code>Geometry</code>
   *@param  SRID            the ID of the Spatial Reference System used by the
   *      <code>Envelope</code>
   *@return                 an empty <code>Point</code> (for null <code>Envelope</code>
   *      s), a <code>Point</code> (when min x = max x and min y = max y) or a
   *      <code>Polygon</code> (in all other cases)
   *@throws  <code>         TopologyException</code> if <code>coordinates</code>
   *      is not a closed linestring, that is, if the first and last coordinates
   *      are not equal
   */
  public static Geometry toGeometry(Envelope envelope, PrecisionModel precisionModel,
      int SRID) {
    if (envelope.isNull()) {
      return new Point(null, precisionModel, SRID);
    }
    if (envelope.getMinX() == envelope.getMaxX() && envelope.getMinY() == envelope.getMaxY()) {
      return new Point(new Coordinate(envelope.getMinX(), envelope.getMinY()), precisionModel, SRID);
    }
    return new Polygon(new LinearRing(new Coordinate[]{
        new Coordinate(envelope.getMinX(), envelope.getMinY()),
        new Coordinate(envelope.getMaxX(), envelope.getMinY()),
        new Coordinate(envelope.getMaxX(), envelope.getMaxY()),
        new Coordinate(envelope.getMinX(), envelope.getMaxY()),
        new Coordinate(envelope.getMinX(), envelope.getMinY())
        }, precisionModel, SRID), precisionModel, SRID);
  }

  public PrecisionModel getPrecisionModel() {
    return precisionModel;
  }

  public Point createPoint(Coordinate coordinate) {
    return new Point(coordinate, precisionModel, SRID);
  }

  public MultiLineString createMultiLineString(LineString[] lineStrings) {
    return new MultiLineString(lineStrings, precisionModel, SRID);
  }

  public GeometryCollection createGeometryCollection(Geometry[] geometries) {
    return new GeometryCollection(geometries, precisionModel, SRID);
  }

  public MultiPolygon createMultiPolygon(Polygon[] polygons) {
    return new MultiPolygon(polygons, precisionModel, SRID);
  }

  public LinearRing createLinearRing(Coordinate[] coordinates) {
    LinearRing linearRing = new LinearRing(coordinates, precisionModel, SRID);
    if (coordinates != null && coordinates.length > 0 && !coordinates[0].equals2D(coordinates[
        coordinates.length - 1])) {
      throw new IllegalArgumentException("LinearRing not closed");
    }
    return linearRing;
  }

  public MultiPoint createMultiPoint(Point[] point) {
    return new MultiPoint(point, precisionModel, SRID);
  }

  public MultiPoint createMultiPoint(Coordinate[] coordinates) {
    if (coordinates == null) {
      coordinates = new Coordinate[]{};
    }
    ArrayList points = new ArrayList();
    for (int i = 0; i < coordinates.length; i++) {
      points.add(createPoint(coordinates[i]));
    }
    return createMultiPoint((Point[]) points.toArray(new Point[]{}));
  }

  public Polygon createPolygon(LinearRing shell, LinearRing[] holes) {
    return new Polygon(shell, holes, precisionModel, SRID);
  }

  /**
   *  Build an appropriate <code>Geometry</code>, <code>MultiGeometry</code>, or
   *  <code>GeometryCollection</code> to contain the <code>Geometry</code>s in
   *  it; for example,<br>
   *
   *  <ul>
   *    <li> If <code>geomList</code> contains a single <code>Polygon</code>,
   *    the <code>Polygon</code> is returned.
   *    <li> If <code>geomList</code> contains several <code>Polygon</code>s, a
   *    <code>MultiPolygon</code> is returned.
   *    <li> If <code>geomList</code> contains some <code>Polygon</code>s and
   *    some <code>LineString</code>s, a <code>GeometryCollection</code> is
   *    returned.
   *    <li> If <code>geomList</code> is empty, an empty <code>GeometryCollection</code>
   *    is returned
   *  </ul>
   *
   *
   *@param  geomList  the <code>Geometry</code>s to combine
   *@return           a <code>Geometry</code> of the "smallest", "most
   *      type-specific" class that can contain the elements of <code>geomList</code>
   *      .
   */
  public Geometry buildGeometry(List geomList) {
    Class geomClass = null;
    boolean isHeterogeneous = false;
    boolean isCollection = geomList.size() > 1;
    for (Iterator i = geomList.iterator(); i.hasNext(); ) {
      Geometry geom = (Geometry) i.next();
      Class partClass = geom.getClass();
      if (geomClass == null) {
        geomClass = partClass;
      }
      if (partClass != geomClass) {
        isHeterogeneous = true;
      }
    }
    // for the empty geometry, return an empty GeometryCollection
    if (geomClass == null) {
      return createGeometryCollection(null);
    }
    if (isHeterogeneous) {
      return createGeometryCollection(toGeometryArray(geomList));
    }
    Geometry geom0 = (Geometry) geomList.get(0);
    if (isCollection) {
      if (geom0 instanceof Polygon) {
        return createMultiPolygon(toPolygonArray(geomList));
      }
      else if (geom0 instanceof LineString) {
        return createMultiLineString(toLineStringArray(geomList));
      }
      else if (geom0 instanceof Point) {
        return createMultiPoint(toPointArray(geomList));
      }
      Assert.shouldNeverReachHere();
    }
    return geom0;
  }

  public LineString createLineString(Coordinate[] coordinates) {
    return new LineString(coordinates, precisionModel, SRID);
  }
}

