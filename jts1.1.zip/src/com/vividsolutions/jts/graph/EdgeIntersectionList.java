/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.graph;

/**
 * A list of edge intersections along an Edge
 * @version 1.1
 */
import java.io.PrintStream;
import java.util.*;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.util.Debug;

public class EdgeIntersectionList
{
  // a List of EdgeIntersections
  List list = new ArrayList();    // more efficient to use a LinkedList, but ArrayList is easier for debugging
  Edge edge;  // the parent edge

  public EdgeIntersectionList(Edge edge)
  {
    this.edge = edge;
  }

  /**
   * Adds an intersection into the list, if it isn't already there.
   * The input segmentIndex and dist are expected to be normalized.
   * @return the EdgeIntersection found or added
   */
  public EdgeIntersection add(Coordinate coord, int segmentIndex, double dist)
  {
//Debug.println("adding edgeInt " + coord + " " + segmentIndex + " " + dist);
    ListIterator insertIt = list.listIterator();
    boolean isInList = findInsertionPoint(segmentIndex, dist, insertIt);
    EdgeIntersection ei;
    if (! isInList) {
      ei = new EdgeIntersection(coord, segmentIndex, dist);
      insertIt.add(ei);
    }
    else
      ei = (EdgeIntersection) insertIt.next();
    return ei;
  }
  /**
   * returns an iterator of EdgeIntersections
   */
  public Iterator iterator() { return list.iterator(); }

  public boolean isEmpty()
  {
    Iterator it = list.iterator();
    return ! it.hasNext();
  }
  /**
   * This routine searches the list for the insertion point for the given intersection
   * (which must be in normalized form).
   * The intersection point may already be in the list - in this case, the intersection
   * is not inserted.
   * If the intersection is new, it is inserted into the list.
   * The insertIt iterator is left pointing at the correct place
   * to insert the intersection, if the intersection was not found.
   *
   * @return true if this intersection is already in the list
   */
  boolean findInsertionPoint(int segmentIndex, double dist, ListIterator insertIt)
  {
    // The insertIt position trails the findIt position by one
    ListIterator findIt = list.listIterator();
    boolean found = false;
    while (findIt.hasNext()) {
      EdgeIntersection ei = (EdgeIntersection) findIt.next();
      int compare = ei.compare(segmentIndex, dist);

      // intersection found - insertIt.next() will retrieve it
      if (compare == 0) return true;

      // this ei is past the intersection location, so intersection was not found
      if (compare > 0) return false;

      // this ei was before the intersection point, so move to next
      insertIt.next();
    }
    return false;
  }
  public boolean isIntersection(Coordinate pt)
  {
    for (Iterator it = list.iterator(); it.hasNext(); ) {
      EdgeIntersection ei = (EdgeIntersection) it.next();
      if (ei.coord.equals(pt))
       return true;
    }
    return false;
  }
  /**
   * Adds entries for the first and last points of the edge to the list
   */
  public void addEndpoints()
  {
    int maxSegIndex = edge.pts.length - 1;
    add(edge.pts[0], 0, 0.0);
    add(edge.pts[maxSegIndex], maxSegIndex, 0.0);
  }

  /**
   * Creates new edges for all the edges that the intersections in this
   * list split the parent edge into.
   * Adds the edges to the input list (this is so a single list
   * can be used to accumulate all split edges for a Geometry).
   */
  public void addSplitEdges(List edgeList)
  {
    // ensure that the list has entries for the first and last point of the edge
    addEndpoints();

    Iterator it = list.iterator();
    // there should always be at least two entries in the list
    EdgeIntersection eiPrev = (EdgeIntersection) it.next();
    while (it.hasNext()) {
      EdgeIntersection ei = (EdgeIntersection) it.next();
      Edge newEdge = createSplitEdge(eiPrev, ei);
      edgeList.add(newEdge);

      eiPrev = ei;
    }
  }
  /**
   * Create a new "split edge" with the section of points between
   * (and including) the two intersections.
   * The label for the new edge is the same as the label for the parent edge.
   */
  Edge createSplitEdge(EdgeIntersection ei0, EdgeIntersection ei1)
  {
//Debug.print("\ncreateSplitEdge"); Debug.print(ei0); Debug.print(ei1);
    int npts = ei1.segmentIndex - ei0.segmentIndex + 2;

    Coordinate lastSegStartPt = edge.pts[ei1.segmentIndex];
    // if the last intersection point is not equal to the its segment start pt,
    // add it to the points list as well.
    // (This check is needed because the distance metric is not totally reliable!)
    boolean useIntPt1 = ei1.dist > 0.0 || ! ei1.coord.equals(lastSegStartPt);
    if (! useIntPt1) {
      npts--;
    }

    Coordinate[] pts = new Coordinate[npts];
    int ipt = 0;
    pts[ipt++] = new Coordinate(ei0.coord);
    for (int i = ei0.segmentIndex + 1; i <= ei1.segmentIndex; i++) {
      pts[ipt++] = edge.pts[i];
    }
    if (useIntPt1) pts[ipt] = ei1.coord;
    return new Edge(pts, new Label(edge.label));
  }

  public void print(PrintStream out)
  {
    out.println("Intersections:");
    for (Iterator it = list.iterator(); it.hasNext(); ) {
      EdgeIntersection ei = (EdgeIntersection) it.next();
      ei.print(out);
    }
  }
}
