/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.buffer;
/**
 * @version 1.1
 */

import java.util.*;
import com.vividsolutions.jts.geom.*;

/**
 * Implements a list of separate point sequences for the edges of a buffer.
 */
public class LineList {
  private static final Coordinate[] arrayTypeCoordinate = new Coordinate[0];

  List lines = new ArrayList();
  List currPtList;

  public LineList() {
    addNewList();
  }

  private void addNewList()
  {
    currPtList = new ArrayList();
    lines.add(currPtList);
  }
  public List getLines()
  {
    List coordLines = new ArrayList();
    for (Iterator i = lines.iterator(); i.hasNext(); ) {
      List ptList = (List) i.next();
      coordLines.add(getCoordinates(ptList));
    }
    return coordLines;
  }

  private Coordinate[] getCoordinates(List ptList)
  {
    Coordinate[] coord = (Coordinate[]) ptList.toArray(arrayTypeCoordinate);
    return coord;
  }


  public void addPt(Coordinate pt)
  {
    Coordinate bufPt = new Coordinate(pt);
    bufPt.makePrecise();
    // don't add duplicate points
    Coordinate lastPt = null;
    if (currPtList.size() >= 1)
      lastPt = (Coordinate) currPtList.get(currPtList.size() - 1);
    if (lastPt != null && bufPt.equals(lastPt)) return;

    currPtList.add(bufPt);
//System.out.println(bufPt);
  }
  public void endEdge()
  {
    if (currPtList.size() < 1) return;
    Coordinate lastPt = (Coordinate) currPtList.get(currPtList.size() - 1);

    // start a new list for the next pt
    addNewList();
  }
}