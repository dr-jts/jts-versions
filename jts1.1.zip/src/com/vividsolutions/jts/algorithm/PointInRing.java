package com.vividsolutions.jts.algorithm;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.1
 */
import com.vividsolutions.jts.geom.Coordinate;

public interface PointInRing {

  boolean isInside(Coordinate pt);
}