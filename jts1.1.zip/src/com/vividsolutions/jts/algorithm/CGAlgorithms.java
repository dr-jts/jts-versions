/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.algorithm;

/**
 * @version 1.1
 */

import com.vividsolutions.jts.geom.Coordinate;

public abstract class CGAlgorithms {

  public static final int CLOCKWISE         = -1;
  public static final int COUNTERCLOCKWISE  = 1;
  public static final int COLLINEAR         = 0;

  public CGAlgorithms() {
  }

  /**
   * Test whether a point lies inside a simple polygon (ring).
   * The ring may be oriented in either direction.
   * If the point lies on the ring boundary the result of this method is unspecified.
   *
   * @return true if the point lies in the interior of the ring
   */
  public abstract boolean isPointInPolygon(Coordinate p, Coordinate[] ring);
  /**
   * Test whether a point lies on a linestring.
   *
   * @return true true if
   * the point is a vertex of the line or lies in the interior of a line
   * segment in the linestring
   */
  public abstract boolean isOnLine(Coordinate p, Coordinate[] linestring);
  /**
   * Test whether a ring (simple polygon) is oriented counter-clockwise.
   *
   * @return true if the ring is oriented counter-clockwise
   */
  public abstract boolean isCCW(Coordinate[] ring);

  /**
   * Computes the orientation of a point q to the directed line segment p1-p2.
   * The orientation of a point relative to a directed line segment indicates
   * which way you turn to get to q after travelling from p1 to p2.
   *
   * @return 1 if q is counter-clockwise from p1-p2
   * @return -1 if q is clockwise from p1-p2
   * @return 0 if q is collinear with p1-p2
   */
  public abstract int computeOrientation(Coordinate p1, Coordinate p2, Coordinate q);

}
