package com.vividsolutions.jts.index.quadtree;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.1
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;

public class Quadtree {


  /**
   * return a square envelope containing the argument envelope
   */
  private static Envelope computeInitialExtent(Envelope env)
  {
    double dx = env.getWidth();
    double dy = env.getHeight();
    double size = dx > dy ? dx : dy;
    double x = env.getMinX();
    double y = env.getMinY();
    return new Envelope(x, x + size, y, y + size);
  }

  private Quad root;

  public Quadtree(Envelope env)
  {
    Envelope quadEnv = computeInitialExtent(env);
    root = new Quad(null, quadEnv);
  }

  public Quad getRoot() { return root; }

  public void insert(Envelope itemEnv, Object item)
  {
   /**
    * Do NOT create a new quad for zero-area envelopes - this would lead
    * to infinite recursion. Instead, use a heuristic of simply returning
    * the smallest existing quad containing the query
    */
    boolean isValid = itemEnv.getHeight() > 0 && itemEnv.getWidth() > 0;
    Quad quad;
    if (isValid)
      quad = root.getQuad(itemEnv);
    else
      quad = root.find(itemEnv);
    quad.add(item);
  }

  public List query(Envelope searchEnv)
  {
    /**
     * the items that are matched are the items in quads which
     * overlap the search envelope
     */
    List foundItems = new ArrayList();
    root.addAllItemsFromOverlapping(searchEnv, foundItems);
    return foundItems;
  }
  /**
   * Internal iterator for queries
   */
  public void query(Envelope searchEnv, QuadtreeSelectAction action)
  {
    /**
     * the items that are selected are the items in quads which
     * overlap the search envelope
     */
    root.selectAllItemsFromOverlapping(searchEnv, action);
  }

  public List queryAll()
  {
    /**
     * the items that are matched are the items in quads which
     * overlap the search envelope
     */
    List foundItems = new ArrayList();
    root.addAllItems(foundItems);
    return foundItems;
  }

  private class QuadtreeIterator
    implements Iterator
  {
    private Envelope searchEnv;
    private Quad currParent;
    private Quad currQuad;
    private Iterator itemIt = null;

    QuadtreeIterator(Envelope searchEnv, Quad root)
    {
    }

    public boolean hasNext()
    {
      if (itemIt == null) computeNextItemIterator();
      if (itemIt != null && itemIt.hasNext()) return true;
      return false;
    }

    /**
     * Returns the next element in the interation.
     *
     * @return the next element in the iteration.
     * @exception NoSuchElementException iteration has no more elements.
     */
    public Object next()
    {
      if (itemIt != null) {
        if (itemIt.hasNext())
          return itemIt.next();
        else {
          itemIt = null;
        }
      }
      return null;  // *** should be changed
    }

    public void remove()
    {
      throw new UnsupportedOperationException();
    }

    private void computeNextItemIterator()
    {
      //if
    }

    /**
     * Get the next subquad after currSub in the subquad array of the parent quad.
     * If currSub is null return the first subquad in the array.
     *
     * @return null if no next subquad found
     */
    private Quad getNextSubquad(Quad parent, Quad currSub)
    {
      if (parent == null) return null;
      Quad[] subquad = parent.subquad;

      int i = 0;
      // skip over all quads up to and including current one
      while (currSub != null && subquad[i] != currSub) {
        i++;
      }
      i++;

      // now find next quad to query, if any
      while (i < 4) {
        if (subquad[i] != null) {
          // search env is specified, so filter by env
          if (searchEnv != null && subquad[i].overlaps(searchEnv))
            break;
          // search env not specified - include all quads
          if (searchEnv == null)
            break;
        }
        i++;
      }

      if (i < 4)
        return subquad[i];
      return null;
    }
  }
}