package com.vividsolutions.jts.index.quadtree;

/**
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;

public class Quad {

  private Envelope env;
  private Coordinate centre;
  private Quad parent;
  private List items = new ArrayList();

  /**
   * subquads are numbered as follows:
   *
   *  2 | 3
   *  --+--
   *  0 | 1
   */
  Quad[] subquad = new Quad[4];

  public Quad(Quad parent, Envelope env)
  {
    this.parent = parent;
    this.env = env;
    centre = new Coordinate();
    centre.x = (env.getMinX() + env.getMaxX()) / 2;
    centre.y = (env.getMinY() + env.getMaxY()) / 2;
  }

  public Quad getParent() { return parent; }

  public List getItems() { return items; }

  public boolean overlaps(Envelope testEnv)
  {
    return this.env.overlaps(testEnv);
  }

  public void add(Object item)
  {
    items.add(item);
  }

  public List addAllItems(List items)
  {
    items.addAll(this.items);
    for (int i = 0; i < 4; i++) {
      if (subquad[i] != null) {
        subquad[i].addAllItems(items);
      }
    }
    return items;
  }
  public List addAllItemsFromOverlapping(Envelope searchEnv, List items)
  {
    if (! env.overlaps(searchEnv))
      return items;

    items.addAll(this.items);

    for (int i = 0; i < 4; i++) {
      if (subquad[i] != null) {
        subquad[i].addAllItemsFromOverlapping(searchEnv, items);
      }
    }
    return items;
  }

  public void selectAllItemsFromOverlapping(Envelope searchEnv, QuadtreeSelectAction action)
  {
    if (! env.overlaps(searchEnv))
      return;

    // select all items from this quad
    for (Iterator itemIt = items.iterator(); itemIt.hasNext(); ) {
      action.select(itemIt.next());
    }

    for (int i = 0; i < 4; i++) {
      if (subquad[i] != null) {
        subquad[i].selectAllItemsFromOverlapping(searchEnv, action);
      }
    }
  }

  /**
   * Returns the quad containing the envelope.  Creates the quad if
   * it does not already exist.
   */
  public Quad getQuad(Envelope searchEnv)
  {
    int subquadIndex = getSubquadIndex(searchEnv);
    if (subquadIndex != -1) {
      // create the quad if it does not exist
      Quad quad = getSubquad(subquadIndex);
      // recursively search the found quad
      return quad.getQuad(searchEnv);
    }
    else {
      return this;
    }
  }

  /**
   * Returns the smallest existing quad containing the envelope.
   */
  public Quad find(Envelope searchEnv)
  {
    int subquadIndex = getSubquadIndex(searchEnv);
    if (subquadIndex == -1)
      return this;
    if (subquad[subquadIndex] != null) {
      // query lies in subquad, so search it
      Quad quad = subquad[subquadIndex];
      return quad.find(searchEnv);
    }
    // no existing subquad, so return this one anyway
    return this;
  }

  /**
   * Returns the index of the subquad that wholely contains the search envelope.
   * If none does, returns -1
   */
  private int getSubquadIndex(Envelope searchEnv)
  {
    int subquadIndex = -1;
    if (searchEnv.getMinX() > centre.x) {
      if (searchEnv.getMinY() > centre.y) subquadIndex = 3;
      if (searchEnv.getMaxY() < centre.y) subquadIndex = 1;
    }
    if (searchEnv.getMaxX() < centre.x) {
      if (searchEnv.getMinY() > centre.y) subquadIndex = 2;
      if (searchEnv.getMaxY() < centre.y) subquadIndex = 0;
    }
    return subquadIndex;
  }
  /**
   * get the subquad for the index.
   * If it doesn't exist, create it
   */
  private Quad getSubquad(int index)
  {
    if (subquad[index] == null) {
      // create a new subquad in the appropriate quadrant

      double minx = 0.0;
      double maxx = 0.0;
      double miny = 0.0;
      double maxy = 0.0;

      switch (index) {
      case 0:
        minx = env.getMinX();
        maxx = centre.x;
        miny = env.getMinY();
        maxy = centre.y;
        break;
      case 1:
        minx = centre.x;
        maxx = env.getMaxX();
        miny = env.getMinY();
        maxy = centre.y;
        break;
      case 2:
        minx = env.getMinX();
        maxx = centre.x;
        miny = centre.y;
        maxy = env.getMaxY();
        break;
      case 3:
        minx = centre.x;
        maxx = env.getMaxX();
        miny = centre.y;
        maxy = env.getMaxY();
        break;
      }
      Envelope sqEnv = new Envelope(minx, maxx, miny, maxy);
      Quad sq = new Quad(this, sqEnv);
      subquad[index] = sq;
    }
    return subquad[index];
  }
}