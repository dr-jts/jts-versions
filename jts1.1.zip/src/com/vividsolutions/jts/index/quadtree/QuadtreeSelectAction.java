package com.vividsolutions.jts.index.quadtree;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.1
 */

public interface QuadtreeSelectAction {

  void select(Object obj);
}