package com.vividsolutions.jts.index.intervaltree;

/**
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;

public class IntervalNode {

  private double min, max;
  private double centre;
  private IntervalNode parent;
  private List items = new ArrayList();

  /**
   * subquads are numbered as follows:
   *
   *  2 | 3
   *  --+--
   *  0 | 1
   */
  private IntervalNode[] subinterval = new IntervalNode[2];

  public IntervalNode(IntervalNode parent, double min, double max)
  {
    this.parent = parent;
    this.min = min;
    this.max = max;
    centre = (min + max) / 2;
  }

  public IntervalNode getParent() { return parent; }
  public IntervalNode[] getChildren() { return subinterval; }

  public boolean overlaps(double qmin, double qmax)
  {
    if (qmin > max || qmax < min) return false;
    return true;
  }

  public List getItems() { return items; }

  public void add(Object item)
  {
    items.add(item);
  }

  /**
   * Collect all items for this node and all nodes below it
   * which overlap the query interval
   */
  public List addAllItemsFromOverlapping(double min, double max, List items)
  {
    items.addAll(this.items);
    for (int i = 0; i < 2; i++) {
      if (subinterval[i] != null && subinterval[i].overlaps(min, max)) {
        subinterval[i].addAllItemsFromOverlapping(min, max, items);
      }
    }
    return items;
  }

  /**
   * Returns the interval containing the envelope.
   * Creates the interval if it does not already exist.
   * Note that passing a zero-size interval to this routine results in infinite recursion.
   */
  public IntervalNode getIntervalNode(double min, double max)
  {
    int subintervalIndex = getSubintervalIndex(min, max);
    if (subintervalIndex != -1) {
      // create the quad if it does not exist
      IntervalNode interval = getSubinterval(subintervalIndex);
      // recursively search the found quad
      return interval.getIntervalNode(min, max);
    }
    else {
      return this;
    }
  }

  /**
   * Returns the smallest existing node containing the envelope.
   */
  public IntervalNode find(double min, double max)
  {
    int subintervalIndex = getSubintervalIndex(min, max);
    if (subintervalIndex == -1 || subinterval[subintervalIndex] == null)
      return this;
    // query lies in subnode, so search it recursively
    IntervalNode node = subinterval[subintervalIndex];
    return node.find(min, max);
  }

  /**
   * Returns the index of the subquad that wholely contains the search envelope.
   * If none does, returns -1
   */
  private int getSubintervalIndex(double min, double max)
  {
    int subintervalIndex = -1;
    if (min > centre) subintervalIndex = 1;
    if (max < centre) subintervalIndex = 0;
    return subintervalIndex;
  }

  /**
   * get the subinterval for the index.
   * If it doesn't exist, create it
   */
  private IntervalNode getSubinterval(int index)
  {
    if (subinterval[index] == null) {
      // create a new subquad in the appropriate quadrant

      double submin = 0.0;
      double submax = 0.0;

      switch (index) {
      case 0:
        submin = min;
        submax = centre;
        break;
      case 1:
        submin = centre;
        submax = max;
        break;
      }
      IntervalNode interval = new IntervalNode(this, submin, submax);
      subinterval[index] = interval;
    }
    return subinterval[index];
  }
}