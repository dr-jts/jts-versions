package com.vividsolutions.jts.index.intervaltree;

/**
 * An <code>IntervalTree</code> is a 1-dimensional version of a quadtree
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;

public class IntervalTree {

  private IntervalNode root;

  public IntervalTree(double min, double max)
  {
    root = new IntervalNode(null, min, max);
  }

  public IntervalNode getRoot() { return root; }

  public void insert(double x1, double x2, Object item)
  {
    double min = Math.min(x1, x2);
    double max = Math.max(x1, x2);
   /**
    * Do NOT create a new interval for zero-length intervals - this would lead
    * to infinite recursion. Instead, use a heuristic of simply returning
    * the smallest existing interval containing the query
    */
    boolean isValid = max > min;
    IntervalNode interval;
    if (isValid)
      interval = root.getIntervalNode(min, max);
    else
      interval = root.find(min, max);
    interval.add(item);
  }

  public List query(double x)
  {
    return query(x, x);
  }

  /**
   * min and max may be the same value
   */
  public List query(double x1, double x2)
  {
    double min = Math.min(x1, x2);
    double max = Math.max(x1, x2);

    /**
     * the items that are matched are all items in intervals
     * which overlap the query interval
     */
    List foundItems = new ArrayList();
    root.addAllItemsFromOverlapping(x1, x2, foundItems);
    return foundItems;
  }

}