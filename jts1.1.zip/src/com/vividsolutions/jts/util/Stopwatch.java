package com.vividsolutions.jts.util;

public class Stopwatch {

  private static long startTime;

  public static void start()
  {
    startTime = System.currentTimeMillis();
  }

  private static long getTime()
  {
    long endTime = System.currentTimeMillis();
    long totalTime = endTime - startTime;
    return totalTime;
  }

  public static String getTimeString()
  {
    long totalTime = getTime();
    String totalTimeStr = totalTime < 10000 ? totalTime + " ms" : (double) totalTime / 1000.0 + " s";
    return totalTimeStr;
  }
}