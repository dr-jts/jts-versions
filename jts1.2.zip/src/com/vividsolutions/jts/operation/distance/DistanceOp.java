/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.distance;

import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.algorithm.*;

/**
 * DistanceOp computes the distance between two Geometries.
 * Currently the algorithms used are straightforward O(n^2)
 * comparisons.  These could definitely be improved on.
 */
public class DistanceOp {

  private static PointLocator ptLocator = new PointLocator();

  public static double distance(Geometry g0, Geometry g1)
  {
    DistanceOp distOp = new DistanceOp(g0, g1);
    return distOp.distance();
  }

  private Geometry[] geom;
  private double minDistance = Double.MAX_VALUE;

  public DistanceOp(Geometry g0, Geometry g1)
  {
    this.geom = new Geometry[2];
    geom[0] = g0;
    geom[1] = g1;
  }

  public double distance()
  {
    computeMinDistance();
    return minDistance;
  }

  private void updateMinDistance(double dist)
  {
    if (dist < minDistance)
      minDistance = dist;
  }

  private void computeMinDistance()
  {
    List polys0 = PolygonExtracterFilter.getPolygons(geom[0]);
    List polys1 = PolygonExtracterFilter.getPolygons(geom[1]);

    if (polys1.size() > 0) {
      List insidePts0 = ConnectedElementPointFilter.getCoordinates(geom[0]);
      computeInside(insidePts0, polys1);
      if (minDistance <= 0.0) return;
    }
    if (polys0.size() > 0) {
      List insidePts1 = ConnectedElementPointFilter.getCoordinates(geom[1]);
      computeInside(insidePts1, polys0);
      if (minDistance <= 0.0) return;
    }

    List lines0 = LineExtracterFilter.getLines(geom[0]);
    List lines1 = LineExtracterFilter.getLines(geom[1]);

    List pts0 = PointExtracterFilter.getPoints(geom[0]);
    List pts1 = PointExtracterFilter.getPoints(geom[1]);
    if (pts0.size() > 0 || pts1.size() > 0) {
      throw new UnsupportedOperationException("points not yet implemented");
    }

    computeMinDistance(lines0, lines1);
    if (minDistance <= 0.0) return;
    computeMinDistance(pts0, pts1);
  }

  private void computeInside(List pts, List polys)
  {
    for (int i = 0; i < pts.size(); i++) {
      Coordinate pt = (Coordinate) pts.get(i);
      for (int j = 0; j < polys.size(); j++) {
        Polygon poly = (Polygon) polys.get(j);
        computeInside(pt, poly);
        if (minDistance <= 0.0) return;
      }
    }
  }

  private void computeInside(Coordinate pt, Polygon poly)
  {
    if (Location.EXTERIOR != ptLocator.locate(pt, poly))
      minDistance = 0.0;
  }

  private void computeMinDistance(List lines0, List lines1)
  {
    for (int i = 0; i < lines0.size(); i++) {
      LineString line0 = (LineString) lines0.get(i);
      for (int j = 0; j < lines1.size(); j++) {
        LineString line1 = (LineString) lines1.get(j);
        computeMinDistance(line0, line1);
      }
    }
  }

  private void computeMinDistance(LineString line0, LineString line1)
  {
    if (line0.getEnvelopeInternal().distance(line1.getEnvelopeInternal())
        > minDistance)
          return;
    Coordinate[] coord0 = line0.getCoordinates();
    Coordinate[] coord1 = line1.getCoordinates();
      // brute force approach!
    for (int i = 0; i < coord0.length - 1; i++) {
      for (int j = 0; j < coord1.length - 1; j++) {
        double dist = CGAlgorithms.distanceLineLine(
                                        coord0[i], coord0[i + 1],
                                        coord1[j], coord1[j + 1] );
        updateMinDistance(dist);
      }
    }
  }


}