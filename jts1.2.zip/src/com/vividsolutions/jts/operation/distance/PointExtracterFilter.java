package com.vividsolutions.jts.operation.distance;

import java.util.*;
import com.vividsolutions.jts.geom.*;

/**
 * A PointExtracterFilter extracts all the component Points from a Geometry
 * and returns them in a list
 */
public class PointExtracterFilter
  implements GeometryFilter
{

  public static List getPoints(Geometry geom)
  {
    List pts = new ArrayList();
    geom.apply(new PointExtracterFilter(pts));
    return pts;
  }

  private List pts;

  PointExtracterFilter(List pts)
  {
    this.pts = pts;
  }

  public void filter(Geometry geom)
  {
    if (geom instanceof Point) pts.add(geom);
  }

}