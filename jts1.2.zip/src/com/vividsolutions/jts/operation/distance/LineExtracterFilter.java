package com.vividsolutions.jts.operation.distance;

import java.util.*;
import com.vividsolutions.jts.geom.*;

/**
 * A LineExtracterFilter extracts all the component LineStrings from a Geometry
 * and returns them in a list
 */
public class LineExtracterFilter
  implements GeometryComponentFilter
{

  public static List getLines(Geometry geom)
  {
    List lines = new ArrayList();
    geom.apply(new LineExtracterFilter(lines));
    return lines;
  }

  private List lines;

  LineExtracterFilter(List lines)
  {
    this.lines = lines;
  }

  public void filter(Geometry geom)
  {
    if (geom instanceof LineString) lines.add(geom);
  }

}