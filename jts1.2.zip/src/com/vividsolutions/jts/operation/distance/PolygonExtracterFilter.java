package com.vividsolutions.jts.operation.distance;

import java.util.*;
import com.vividsolutions.jts.geom.*;

/**
 * A PolygonExtracterFilter extracts all the component Polygons from a Geometry
 * and returns them in a list
 */
public class PolygonExtracterFilter
  implements GeometryFilter
{

  public static List getPolygons(Geometry geom)
  {
    List comps = new ArrayList();
    geom.apply(new PolygonExtracterFilter(comps));
    return comps;
  }

  private List comps;

  PolygonExtracterFilter(List comps)
  {
    this.comps = comps;
  }

  public void filter(Geometry geom)
  {
    if (geom instanceof Polygon) comps.add(geom);
  }

}