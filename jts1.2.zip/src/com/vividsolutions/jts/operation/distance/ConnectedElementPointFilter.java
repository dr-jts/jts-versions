package com.vividsolutions.jts.operation.distance;

import java.util.*;
import com.vividsolutions.jts.geom.*;

/**
 * A ConnectedElementPointFilter extracts a single point
 * from each connected element in a Geometry
 * (e.g. a polygon, linestring or point)
 * and returns them in a list
 */
public class ConnectedElementPointFilter
  implements GeometryFilter
{

  public static List getCoordinates(Geometry geom)
  {
    List pts = new ArrayList();
    geom.apply(new ConnectedElementPointFilter(pts));
    return pts;
  }

  private List pts;

  ConnectedElementPointFilter(List pts)
  {
    this.pts = pts;
  }

  public void filter(Geometry geom)
  {
    if (geom instanceof Point
      || geom instanceof LineString
      || geom instanceof Polygon )
      pts.add(geom.getCoordinate());
  }

}