/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.graph.index;

/**
 * @version 1.2
 */
import java.util.*;
import com.vividsolutions.jts.graph.*;

public class SimpleMCSweepLineIntersector
  extends EdgeSetIntersector
{

  List events = new ArrayList();
  // statistics information
  int nOverlaps;

  /**
   * A SimpleMCSweepLineIntersector creates monotone chains from the edges
   * and compares them using a simple sweep-line along the x-axis.
   */
  public SimpleMCSweepLineIntersector() {
  }

  public void computeIntersections(List edges, SegmentIntersector si)
  {
    add(edges, 0);
    computeIntersections(si, false);
  }

  public void computeIntersections(List edges0, List edges1, SegmentIntersector si)
  {
    add(edges0, 0);
    add(edges1, 1);
    computeIntersections(si, true);
  }

  private void add(List edges, int geomIndex)
  {
    for (Iterator i = edges.iterator(); i.hasNext(); ) {
      Edge edge = (Edge) i.next();
      add(edge, geomIndex);
    }
  }

  private void add(Edge edge, int geomIndex)
  {
    MonotoneChainEdge mce = edge.getMonotoneChainEdge();
    int[] startIndex = mce.getStartIndexes();
    for (int i = 0; i < startIndex.length - 1; i++) {
      MonotoneChain mc = new MonotoneChain(mce, i, geomIndex);
      SweepLineEvent insertEvent = new SweepLineEvent(geomIndex, mce.getMinX(i), null, mc);
      events.add(insertEvent);
      events.add(new SweepLineEvent(geomIndex, mce.getMaxX(i), insertEvent, mc));
    }
  }

  /**
   * Because Delete Events have a link to their corresponding Insert event,
   * it is possible to compute exactly the range of events which must be
   * compared to a given Insert event object.
   */
  private void prepareEvents()
  {
    Collections.sort(events);
    for (int i = 0; i < events.size(); i++ )
    {
      SweepLineEvent ev = (SweepLineEvent) events.get(i);
      if (ev.isDelete()) {
        ev.getInsertEvent().setDeleteEventIndex(i);
      }
    }
  }

  private void computeIntersections(SegmentIntersector si, boolean doMutualOnly)
  {
    nOverlaps = 0;
    prepareEvents();

    for (int i = 0; i < events.size(); i++ )
    {
      SweepLineEvent ev = (SweepLineEvent) events.get(i);
      MonotoneChain mc = (MonotoneChain) ev.getObject();
      if (ev.isInsert()) {
        processOverlaps(i, ev.getDeleteEventIndex(), mc, si, doMutualOnly);
      }
    }
  }

  private void processOverlaps(int start, int end, MonotoneChain mc0, SegmentIntersector si, boolean doMutualOnly)
  {
    /**
     * Since we might need to test for self-intersections,
     * include current insert event object in list of event objects to test.
     * Last index can be skipped, because it must be a Delete event.
     */
    for (int i = start; i < end; i++ ) {
      SweepLineEvent ev = (SweepLineEvent) events.get(i);
      if (ev.isInsert()) {
        MonotoneChain mc1 = (MonotoneChain) ev.getObject();
        if (! doMutualOnly || (mc0.geomIndex != mc1.geomIndex)) {
          mc0.computeIntersections(mc1, si);
          nOverlaps++;
        }
      }
    }

  }
}
