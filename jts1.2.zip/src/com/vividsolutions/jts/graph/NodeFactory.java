package com.vividsolutions.jts.graph;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.2
 */
import com.vividsolutions.jts.geom.Coordinate;

public class NodeFactory {
/**
 * The basic node constructor does not allow for incident edges
 */
  public Node createNode(Coordinate coord)
  {
    return new Node(coord, null);
  }
}