package com.vividsolutions.jts.index;

/**
 * The basic functions provided by all spatial indexes
 */
import java.util.*;
import com.vividsolutions.jts.geom.Envelope;

public interface SpatialIndex
{
  /**
   * Adds a spatial item to the index with the given envelope
   */
  void insert(Envelope itemEnv, Object item);
  /**
   * Queries the index for all items whose envelopes intersect the given search envelope
   *
   * @param searchEnv the envelope to query for
   * @return a list of the items found by the query
   */
  List query(Envelope searchEnv);
}