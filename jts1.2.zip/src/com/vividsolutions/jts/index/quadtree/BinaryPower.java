package com.vividsolutions.jts.index.quadtree;

/**
 * <code>BinaryPower</code> computes exponents and powers of 2.
 * It uses algorithsm which use mathematical operations
 * rather than bit manipulation, and as such is vulnerable
 * to errors due to round-off error.
 * It is preferable to use the <code>DoubleBits</code> class.
 */

//<<TODO:REFACTOR?>> If it is preferable to use DoubleBits, should we not delete
//this class? [Jon Aquino]

public class BinaryPower
{
  private static final double LOG_2 = Math.log(2.0);
  /**
   * Computes the exponent for the largest power of two
   * less than the absolute value of the argument.
   * In other words, finds the value n such that
   * 2^n <= abs(num) < 2^(n+1)
   *
   * @return the exponent
   */
  public static int exponent(double num)
  {
    num = Math.abs(num);
    double log = Math.log(num);
    double log2 = log / LOG_2;
    int exp = (int) Math.floor(log2);

///*  TESTING
    int exp2 = DoubleBits.exponent(num);
    if (exp != exp2) {
      System.out.println(DoubleBits.toBinaryString(num));
      System.out.println(num + " pow2 mismatch: " + exp + "   DoubleBits: " + exp2);
      double pow2exp = DoubleBits.powerOf2(exp);
      double pow2exp2 = DoubleBits.powerOf2(exp2);
      System.out.println(pow2exp + "   pow2exp2 = " + pow2exp2);
    }
//*/
    return exp;
  }

  /**
   * This value indicates the expected range of requests
   */
  private static final int MAX_POWER = 100;

  private double[] pow2Pos = new double[MAX_POWER];
  private double[] pow2Neg = new double[MAX_POWER];

  public BinaryPower()
  {
    init();
  }

  /**
   * initialize the cache of powers
   */
  private void init()
  {
    double posPow2 = 1.0;
    double negPow2 = 1.0;
    for (int i = 0; i < MAX_POWER; i++) {
      pow2Pos[i] = posPow2;
      posPow2 *= 2.0;

      pow2Neg[i] = negPow2;
      negPow2 /= 2.0;
    }
  }

  /**
   * Computes the signed largest power of two
   * less than the absolute value of the argument.
   * In other words, finds the value
   *
   * sgn(n) * 2^n
   *
   * such that
   *
   * 2^n <= abs(num) < 2^(n+1)
   *
   * @return the power of two
   */
  public double power(int exp)
  {
    double pow;
    if (exp >= MAX_POWER || exp <= -MAX_POWER)
      pow = Math.pow(2.0, (double) exp);
    // use the precomputed values
    if (exp >= 0)
      pow = pow2Pos[exp];
    else
      pow = pow2Neg[-exp];
    if (pow != DoubleBits.powerOf2(exp))
      System.out.println("pow2 " + exp + " mismatch: " + pow + " DoubleBits: " + DoubleBits.powerOf2(exp));
    return pow;
  }

}