package com.vividsolutions.jts.index.strtree;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.*;

import java.util.*;

/**
 * A node of the STR tree. A leaf node may not have child nodes, but may have
 * child boundables: ItemBoundables.
 */
public abstract class AbstractNode implements Boundable {
  private ArrayList childBoundables = new ArrayList();
  private Object bounds = null;
  private int level;

  public AbstractNode(int level) {
    this.level = level;
  }

  public List getChildBoundables() {
    return childBoundables;
  }

  protected abstract Object computeBounds();

  public Object getBounds() {
    if (bounds == null) {
      bounds = computeBounds();
    }
    return bounds;
  }

  public int getLevel() {
    return level;
  }

  /**
   *@param  childBoundable  either a Node or an ItemBoundable
   */
  public void addChildBoundable(Boundable childBoundable) {
    Assert.isTrue(bounds == null);
    childBoundables.add(childBoundable);
  }
}
