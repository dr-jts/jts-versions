package com.vividsolutions.jts.index.strtree;

import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.*;
import java.util.*;

public class ItemBoundable implements Boundable {
  private Object bounds;
  private Object item;

  public ItemBoundable(Object bounds, Object item) {
    this.bounds = bounds;
    this.item = item;
  }

  public Object getBounds() {
    return bounds;
  }

  public Object getItem() { return item; }
}
