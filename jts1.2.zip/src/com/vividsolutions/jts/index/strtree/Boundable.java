package com.vividsolutions.jts.index.strtree;

import java.util.*;

public interface Boundable {
  public Object getBounds();
}