package com.vividsolutions.jts.index.strtree;
import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.util.*;
import java.util.*;
import java.util.List;

/**
 * Base class for STRtree and SIRtree. STR-packed R-trees are described in:
 * P. Rigaux, Michel Scholl and Agnes Voisard. Spatial Databases With
 * Application To GIS. Morgan Kaufmann, San Francisco, 2002.
 * @see STRtree
 */
public abstract class AbstractSTRtree {

  protected static interface IntersectsOp {
    public boolean intersects(Object aBounds, Object bBounds);
  }

  protected AbstractNode root;

  private boolean built = false;
  private ArrayList itemBoundables = new ArrayList();
  private int nodeCapacity;

  public AbstractSTRtree(int nodeCapacity) {
    Assert.isTrue(nodeCapacity > 1, "Node capacity must be greater than 1");
    this.nodeCapacity = nodeCapacity;
  }

  public void build() {
    Assert.isTrue(!built);
    root = itemBoundables.isEmpty()
           ?createNode(0)
           :createHigherLevels(itemBoundables, -1);
    built = true;
  }

  public void checkConsistency() {
    if (!built) { build(); }
    HashSet itemBoundablesInTree = new HashSet(boundablesAtLevel(-1));
    Assert.equals(new Integer(new HashSet(itemBoundables).size()),
                  new Integer(itemBoundablesInTree.size()));
  }

  protected abstract AbstractNode createNode(int level);

  /**
   * Sorts the childBoundables then divides them into groups of size M, where
   * M is the node capacity.
   */
  protected List createParentBoundables(List childBoundables, int newLevel) {
    Assert.isTrue(!childBoundables.isEmpty());
    ArrayList parentBoundables = new ArrayList();
    parentBoundables.add(createNode(newLevel));
    ArrayList sortedChildBoundables = new ArrayList(childBoundables);
    Collections.sort(sortedChildBoundables, getComparator());
    for (Iterator i = sortedChildBoundables.iterator(); i.hasNext(); ) {
      Boundable childBoundable = (Boundable) i.next();
      if (lastNode(parentBoundables).getChildBoundables().size() == nodeCapacity) {
        parentBoundables.add(createNode(newLevel));
      }
      lastNode(parentBoundables).addChildBoundable(childBoundable);
    }
    return parentBoundables;
  }

  protected abstract Comparator getComparator();

  protected AbstractNode lastNode(List nodes) {
    return (AbstractNode) nodes.get(nodes.size() - 1);
  }

  protected int compareDoubles(double a, double b) {
    return a > b ? 1
         : a < b ? -1
         : 0;
  }

  /**
   *  Creates the levels higher than the given level
   *
   *@param  boundablesOfALevel  the level to build on
   *@param  level               the level of the Boundables, or -1 if the
   *      boundables are item boundables (that is, below level 0)
   *@return                     the root, which may be a ParentNode or a
   *      LeafNode
   */
  private AbstractNode createHigherLevels(List boundablesOfALevel, int level) {
    Assert.isTrue(!boundablesOfALevel.isEmpty());
    List parentBoundables = createParentBoundables(boundablesOfALevel, level + 1);
    if (parentBoundables.size() == 1) {
      return (AbstractNode) parentBoundables.get(0);
    }
    return createHigherLevels(parentBoundables, level + 1);
  }

  protected AbstractNode getRoot() { return root; }
  public int getNodeCapacity() { return nodeCapacity; }

  protected void insert(Object bounds, Object item) {
    Assert.isTrue(!built, "Cannot insert items into an STR packed R-tree after it has been built.");
    itemBoundables.add(new ItemBoundable(bounds, item));
  }

  /**
   *  Also builds the tree, if necessary.
   */
  protected List query(Object searchBounds) {
    if (!built) { build(); }
    ArrayList matches = new ArrayList();
    if (itemBoundables.isEmpty()) {
      Assert.isTrue(root.getBounds() == null);
      return matches;
    }
    if (getIntersectsOp().intersects(root.getBounds(), searchBounds)) {
      query(searchBounds, root, matches);
    }
    return matches;
  }

  protected abstract IntersectsOp getIntersectsOp();

  private void query(Object searchBounds, AbstractNode node, List matches) {
    for (Iterator i = node.getChildBoundables().iterator(); i.hasNext(); ) {
      Boundable childBoundable = (Boundable) i.next();
      if (!getIntersectsOp().intersects(childBoundable.getBounds(), searchBounds)) {
        continue;
      }
      if (childBoundable instanceof AbstractNode) {
        query(searchBounds, (AbstractNode) childBoundable, matches);
      }
      else if (childBoundable instanceof ItemBoundable) {
        matches.add(((ItemBoundable)childBoundable).getItem());
      }
      else {
        Assert.shouldNeverReachHere();
      }
    }
  }

  protected List boundablesAtLevel(int level) {
    ArrayList boundables = new ArrayList();
    boundablesAtLevel(level, root, boundables);
    return boundables;
  }

  /**
   * @param level -1 to get items
   */
  private void boundablesAtLevel(int level, AbstractNode top, Collection boundables) {
    Assert.isTrue(level > -2);
    if (top.getLevel() == level) {
      boundables.add(top);
      return;
    }
    for (Iterator i = top.getChildBoundables().iterator(); i.hasNext(); ) {
      Boundable boundable = (Boundable) i.next();
      if (boundable instanceof AbstractNode) {
        boundablesAtLevel(level, (AbstractNode)boundable, boundables);
      }
      else {
        Assert.isTrue(boundable instanceof ItemBoundable);
        if (level == -1) { boundables.add(boundable); }
      }
    }
    return;
  }

}
