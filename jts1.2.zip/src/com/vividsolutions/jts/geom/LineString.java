/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.geom.sfs.SFSLineString;
import java.util.ArrayList;
import java.util.Arrays;
import com.vividsolutions.jts.operation.IsSimpleOp;
import com.vividsolutions.jts.algorithm.CGAlgorithms;

/**
 *  Basic implementation of <code>LineString</code>.
 *
 *@version 1.2
 */
public class LineString extends Geometry implements SFSLineString {

  /**
   *  The points of this <code>LineString</code>.
   */
  protected Coordinate points[];

  /**
   *  Constructs a <code>LineString</code> with the given points.
   *
   *@param  points          the points of the linestring, or <code>null</code>
   *      to create the empty geometry. This array must not contain <code>null</code>
   *      elements. Consecutive points may not be equal.
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>LineString</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>LineString</code>
   */
  public LineString(Coordinate points[], PrecisionModel precisionModel, int SRID) {
    super(precisionModel, SRID);
    if (points == null) {
      points = new Coordinate[]{};
    }
    if (hasNullElements(points)) {
      throw new IllegalArgumentException("point array must not contain null elements");
    }
    if (points.length == 1) {
      throw new IllegalArgumentException("point array must contain 0 or >1 elements");
    }
    this.points = points;
  }

  public Coordinate[] getCoordinates() {
    return points;
  }

  public Coordinate getCoordinateN(int n) {
    return points[n];
  }

  public Coordinate getCoordinate()
  {
    if (isEmpty()) return null;
    return points[0];
  }

  public int getDimension() {
    return 1;
  }

  public int getBoundaryDimension() {
    if (isClosed()) {
      return Dimension.FALSE;
    }
    return 0;
  }

  public boolean isEmpty() {
    return points.length == 0;
  }

  public int getNumPoints() {
    return points.length;
  }

  public Point getPointN(int n) {
    return new Point(points[n], getPrecisionModel(), SRID);
  }

  public Point getStartPoint() {
    if (isEmpty()) {
      return null;
    }
    return getPointN(0);
  }

  public Point getEndPoint() {
    if (isEmpty()) {
      return null;
    }
    return getPointN(getNumPoints() - 1);
  }

  public boolean isClosed() {
    if (isEmpty()) {
      return false;
    }
    return getCoordinateN(0).equals2D(getCoordinateN(getNumPoints() - 1));
  }

  public boolean isRing() {
    return isClosed() && isSimple();
  }

  public String getGeometryType() {
    return "LineString";
  }

  /**
   *  Returns the length of this <code>LineString</code>
   *
   *@return the area of the polygon
   */
  public double getLength()
  {
   return CGAlgorithms.length(points);
  }

  public boolean isSimple()
  {
    return (new IsSimpleOp()).isSimple(this);
  }

  public Geometry getBoundary() {
    if (isEmpty()) {
      return new GeometryCollection(null, precisionModel, SRID);
    }
    if (isClosed()) {
      return new MultiPoint(null, precisionModel, SRID);
    }
    return new MultiPoint(new Point[]{
        getStartPoint(), getEndPoint()
        }, precisionModel, SRID);
  }


  /**
   *  Returns true if the given point is a vertex of this <code>LineString</code>
   *  .
   *
   *@param  pt  the <code>Coordinate</code> to check
   *@return     <code>true</code> if <code>pt</code> is one of this <code>LineString</code>
   *      's vertices
   */
  public boolean isCoordinate(Coordinate pt) {
    for (int i = 1; i < points.length; i++) {
      if (points[i].equals(pt)) {
        return true;
      }
    }
    return false;
  }

  protected Envelope computeEnvelopeInternal() {
    if (isEmpty()) {
      return new Envelope();
    }
    double minx = points[0].x;
    double miny = points[0].y;
    double maxx = points[0].x;
    double maxy = points[0].y;
    for (int i = 1; i < points.length; i++) {
      minx = Math.min(minx, points[i].x);
      maxx = Math.max(maxx, points[i].x);
      miny = Math.min(miny, points[i].y);
      maxy = Math.max(maxy, points[i].y);
    }
    return new Envelope(minx, maxx, miny, maxy);
  }

  public boolean equalsExact(Geometry other) {
    if (!isEquivalentClass(other)) {
      return false;
    }
    LineString otherLineString = (LineString) other;
    if (points.length != otherLineString.points.length) {
      return false;
    }
    for (int i = 0; i < points.length; i++) {
      if (!points[i].equals(otherLineString.points[i])) {
        return false;
      }
    }
    return true;
  }

  public void apply(CoordinateFilter filter) {
    for (int i = 0; i < points.length; i++) {
      filter.filter(points[i]);
    }
  }

  public void apply(GeometryFilter filter) {
    filter.filter(this);
  }

  public void apply(GeometryComponentFilter filter) {
    filter.filter(this);
  }

  public Object clone() {
    LineString ls = (LineString) super.clone();
    Coordinate[] pts = new Coordinate[points.length];
    ls.points = pts;
    for (int i = 0; i < points.length; i++) {
      ls.points[i] = (Coordinate) points[i].clone();
    }
    return ls;// return the clone
  }

  public void normalize() {
    for (int i = 0; i < points.length; i++) {
      int j = points.length - 1 - i;
      if (!points[i].equals(points[j])) {
        if (points[i].compareTo(points[j]) > 0) {
          reversePointOrder(points);
        }
        return;
      }
    }
  }

  protected boolean isEquivalentClass(Geometry other) {
    return other instanceof LineString;
  }

  protected int compareToSameClass(Object o) {
    ArrayList theseElements = new ArrayList(Arrays.asList(points));
    ArrayList otherElements = new ArrayList(Arrays.asList(((LineString) o).points));
    return compare(theseElements, otherElements);
  }

}

