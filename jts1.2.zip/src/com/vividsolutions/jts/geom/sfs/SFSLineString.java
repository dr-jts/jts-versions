/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom.sfs;

import com.vividsolutions.jts.geom.*;

/**
 *  A <code>Curve</code> with linear interpolation between points. We are using
 *  the definition of <code>LineString</code> given in the <A
 *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
 *  Specification for SQL</A> . This differs in an important way from some other
 *  spatial models (e.g. the one use by ESRI ArcSDE). The difference is that
 *  <code>LineString</code>s may be non-simple. They may self-intersect in
 *  points or line segments. <P>
 *
 *  In fact boundary points of a curve (e.g. the endpoints) may intersect the
 *  interior of the curve, resulting in a curve that is technically
 *  topologically closed but not closed according to the SFS. In this case
 *  topologically the point of intersection would not be on the boundary of the
 *  curve. However, according to the SFS definition the point is considered to
 *  be on the boundary, and JTS follows this definition. <P>
 *
 *  If the <code>LineString</code> is empty, <code>isClosed</code> and <code>isRing</code>
 *  return <code>false</code>. <P>
 *
 *  A <code>LineString</code> is simple if it does not pass through the same
 *  point twice (excepting the endpoints, which may be identical)
 *
 *@version 1.2
 */
public interface SFSLineString extends SFSCurve {

  /**
   *  Returns this <code>LineString</code>s point count.
   *
   *@return    the number of <code>Point</code>s in this <code>LineString</code>
   *      .
   */
  public int getNumPoints();

  /**
   *  Returns the <code>Point</code> at the given index.
   *
   *@param  n  the index of the <code>Point</code> to return (n = 0, 1, 2, ...)
   *@return    the Nth <code>Point</code> in this <code>LineString</code>
   */
  public Point getPointN(int n);

  /**
   *  Returns the <code>Coordinate</code> at the given index.
   *
   *@param  n  the index of the <code>Coordinate</code> to return (n = 0, 1, 2, ...)
   *
   *@return    the Nth <code>Coordinate</code> in this <code>LineString</code>
   */
  public Coordinate getCoordinateN(int n);
}


