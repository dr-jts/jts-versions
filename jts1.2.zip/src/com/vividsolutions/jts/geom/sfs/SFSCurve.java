/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom.sfs;

import com.vividsolutions.jts.geom.*;

/**
 *  A one-dimensional geometric object. Curves may not be degenerate. That is,
 *  non-empty Curves must have at least 2 points, and no two consecutive points
 *  may be equal. <P>
 *
 *  <code>isSimple</code> returns <code>true</code> if the <code>Curve</code>
 *  does not pass through the same point more than once. <p>
 *
 *  The boundary of a closed curve is the empty geometry. The boundary of a
 *  non-closed curve is the two endpoints. <P>
 *
 *  For a precise definition of a curve, see the <A
 *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
 *  Specification for SQL</A> .
 *
 *@version 1.2
 */
public interface SFSCurve extends SFSGeometry {

  /**
   *  Returns the first point with which this <code>Curve</code> object was
   *  constructed.
   *
   *@return    the start point, or <code>null</code> if this <code>Curve</code>
   *      is empty
   */
  Point getStartPoint();

  /**
   *  Returns the last point with which this <code>Curve</code> object was
   *  constructed.
   *
   *@return    the end point, or <code>null</code> if this <code>Curve</code> is
   *      empty
   */
  Point getEndPoint();

  /**
   *  Returns <code>true</code> if the start point and the end point are equal.
   *
   *@return    whether the start and end points are equal. Classes implementing
   *      <code>Curve</code> should document what <code>isClosed</code> returns
   *      if the <code>Curve</code> is empty.
   */
  boolean isClosed();

  /**
   *  Returns <code>true</code> if this <code>Curve</code> is closed and simple.
   *
   *@return    <code>true</code> if this <code>Curve</code> is closed and does
   *      not pass through the same point more than once
   */
  boolean isRing();

  /**
   *  Returns <code>true</code> if this <code>Curve</code> does not pass through
   *  the same point more than once. For a precise definition, see the OpenGIS
   *  Simple Features Specification.
   *
   *@return    <code>true</code> if this <code>Curve</code> does not pass
   *      through the same point more than once.
   */
  boolean isSimple();
}

