/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom.sfs;

import com.vividsolutions.jts.geom.*;

/**
 *  A set of points. The spatial relationship predicates (like <code>disjoint</code>
 *  ) are based on the Dimensionally Extended Nine-Intersection Model (DE-9IM).
 *  For a description of the DE-9IM, see the <A
 *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
 *  Specification for SQL</A> . <P>
 *
 *  A Precision Model object is a member of every Geometry object. <P>
 *
 *  The SFS specifies that objects of each Geometry subclass may be empty. It is
 *  sometimes necessary to construct a generic empty object of class Geometry
 *  (e.g. if the exact type of the Geometry to be returned is not known). The
 *  SFS does not define a specific class or object to represent a generic
 *  empty Geometry. JTS uses the convention that an empty GeometryCollection
 *  will be returned.
 *
 *  <H3> Binary Predicates </H3>
 *  The binary predicates can be
 *  completely specified in terms of an <code>IntersectionMatrix</code> pattern.
 *  In fact, their implementation is simply a call to <code>relate</code> with
 *  the appropriate pattern. <P>
 *
 *  It is important to note that binary predicates are topological operations
 *  rather than pointwise operations. Even for apparently straightforward
 *  predicates such as <code>equals</code> it is easy to find cases where a
 *  pointwise comparison does not produce the same result as a topological
 *  comparison. (for instance: <I>A</I> and <I>B</I> are <code>MultiPoint</code>
 *  s with the same point repeated different numbers of times; <I>A</I> is a
 *  <code>LineString</code> with two collinear line segments and <I>B</I> is a
 *  single line segment with the same start and endpoints). The algorithm used
 *  for the <code>relate</code> method is a topology-based algorithm which
 *  produces a topologically correct result. <P>
 *
 *  As in the SFS, the term <I>P</I> is used to refer to 0-dimensional <code>Geometry</code>
 *  s (<code>Point</code> and <code>MultiPoint</code>), <I>L</I> to
 *  1-dimensional <code>Geometry</code>s ( <code>LineString</code>, and <code>MultiLineString</code>
 *  ), and <I>A</I> to 2-dimensional <code>Geometry</code>s (<code>Polygon</code>
 *  and <code>MultiPolygon</code>). The dimension of a <code>GeometryCollection</code>
 *  is equal to the maximum dimension of its components. <P>
 *
 *  In the SFS some binary predicates are stated to be undefined for some
 *  combinations of dimensions (e.g. touches is undefined for <I>P</I> /<I>P</I>
 *  ). In the interests of simplifying the API, combinations of argument <code>Geometry</code>
 *  s which are not in the domain of a predicate will return <code>false</code>
 *  (e.g. <code>touches(Point, Point) => false</code>). <P>
 *
 *  If either argument to a predicate is an empty <code>Geometry</code> the
 *  predicate will return <code>false</code>. <H3>Set-Theoretic Methods</H3> For
 *  certain inputs, the <code>difference</code> and <code>symDifference</code>
 *  methods may compute non-closed sets. This can happen when the arguments
 *  overlap and have different dimensions. Since JTS <code>Geometry</code>
 *  objects can represent only closed sets, the spatial analysis methods are
 *  specified to return the closure of the point-set-theoretic result.
 *
 *@version 1.2
 */
public interface SFSGeometry {

  /**
   *  Returns the ID of the Spatial Reference System used by the <code>Geometry</code>
   *  . <P>
   *
   *  JTS supports Spatial Reference System information in the simple way
   *  defined in the SFS. A Spatial Reference System ID (SRID) is present in
   *  each <code>Geometry</code> object. <code>Geometry</code> provides basic
   *  accessor operations for this field, but no others. The SRID is represented
   *  as an integer.
   *
   *@return    the ID of the coordinate space in which the <code>Geometry</code>
   *      is defined.
   */
  int getSRID();

  /**
   *  Returns the name of this object's <code>com.vivid.jts.geom</code>
   *  interface.
   *
   *@return    the name of this <code>Geometry</code>s most specific <code>com.vividsolutions.jts.geom</code>
   *      interface
   */
  String getGeometryType();

  /**
   *  Returns the <code>PrecisionModel</code> used by the <code>Geometry</code>.
   *
   *@return    the specification of the grid of allowable points, for this
   *      <code>Geometry</code> and all other <code>Geometry</code>s
   */
  PrecisionModel getPrecisionModel();

  /**
   *  Returns the minimum and maximum x and y values in this <code>Geometry</code>
   *  , or a null <code>Envelope</code> if this <code>Geometry</code> is empty.
   *
   *@return    this <code>Geometry</code>s bounding box; if the <code>Geometry</code>
   *      is empty, <code>Envelope#isNull</code> will return <code>true</code>
   */
  Envelope getEnvelopeInternal();

  /**
   *  Returns this <code>Geometry</code>s bounding box. If this <code>Geometry</code>
   *  is the empty geometry, returns an empty <code>Point</code>. If the <code>Geometry</code>
   *  is a point, returns a non-empty <code>Point</code>. Otherwise, returns a
   *  <code>Polygon</code> whose points are (minx, miny), (maxx, miny), (maxx,
   *  maxy), (minx, maxy), (minx, miny).
   *
   *@return    an empty <code>Point</code> (for empty <code>Geometry</code>s), a
   *      <code>Point</code> (for <code>Point</code>s) or a <code>Polygon</code>
   *      (in all other cases)
   */
  Geometry getEnvelope();

  /**
   *  Returns whether or not the set of points in this <code>Geometry</code> is
   *  empty.
   *
   *@return    <code>true</code> if this <code>Geometry</code> equals the empty
   *      geometry
   */
  boolean isEmpty();

  /**
   *  Returns false if the <code>Geometry</code> has any anomalous points.
   *  Subinterfaces can refine this definition of "simple" in their comments. If
   *  this <code>Geometry</code> is empty, returns <code>true</code>. <P>
   *
   *  In general, the SFS specifications of simplicity seem to follow the
   *  following rule:
   *  <UL>
   *    <LI> A Geometry is simple iff the only self-intersections are at
   *    boundary points.
   *  </UL>
   *  For all empty <code>Geometry</code>s, <code>isSimple</code> = <code>true</code>
   *  .
   *
   *@return    <code>true</code> if this <code>Geometry</code> has any points of
   *      self-tangency, self-intersection or other anomalous points
   */
  boolean isSimple();

  /**
   *  Returns the boundary, or the empty geometry if this <code>Geometry</code>
   *  is empty. For a discussion of this function, see the OpenGIS Simple
   *  Features Specification. As stated in SFS Section 2.1.13.1, "the boundary
   *  of a Geometry is a set of Geometries of the next lower dimension."
   *
   *@return    the closure of the combinatorial boundary of this <code>Geometry</code>
   *      .
   */
  Geometry getBoundary();

  /**
   *  Returns the inherent dimension of this <code>Geometry</code>.
   *
   *@return    the dimension of the class implementing this interface, whether
   *      or not this object is the empty geometry
   */
  int getDimension();

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is T*F**FFF*.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s are equal
   */
  boolean equals(Geometry other);

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is FF*FF****.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s are
   *      disjoint
   */
  boolean disjoint(Geometry other);

  /**
   *  Returns <code>true</code> if <code>disjoint</code> returns false.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s intersect
   */
  boolean intersects(Geometry other);

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is FT*******, F**T***** or F***T****.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s touch;
   *      Returns false if both <code>Geometry</code>s are points
   */
  boolean touches(Geometry other);

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is
   *  <UL>
   *    <LI> T*T****** (for a point and a curve, a point and an area or a line
   *    and an area)
   *    <LI> 0******** (for two curves)
   *  </UL>
   *  .
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s cross.
   *      For this function to return <code>true</code>, the <code>Geometry</code>
   *      s must be a point and a curve; a point and a surface; two curves; or a
   *      curve and a surface.
   */
  boolean crosses(Geometry other);

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is T*F**F***.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if this <code>Geometry</code> is within
   *      <code>other</code>
   */
  boolean within(Geometry other);

  /**
   *  Returns <code>true</code> if <code>other.within(this)</code> returns
   *  <code>true</code>.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if this <code>Geometry</code> contains
   *      <code>other</code>
   */
  boolean contains(Geometry other);

  /**
   *  Returns <code>true</code> if the DE-9IM intersection matrix for the two
   *  <code>Geometry</code>s is
   *  <UL>
   *    <LI> T*T***T** (for two points or two surfaces)
   *    <LI> 1*T***T** (for two curves)
   *  </UL>
   *  .
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        <code>true</code> if the two <code>Geometry</code>s overlap.
   *      For this function to return <code>true</code>, the <code>Geometry</code>
   *      s must be two points, two curves or two surfaces.
   */
  boolean overlaps(Geometry other);

  /**
   *  Returns <code>true</code> if the elements in the DE-9IM intersection
   *  matrix for the two <code>Geometry</code>s match the elements in <code>intersectionPattern</code>
   *  , which may be:
   *  <UL>
   *    <LI> 0
   *    <LI> 1
   *    <LI> 2
   *    <LI> T ( = 0, 1 or 2)
   *    <LI> F ( = -1)
   *    <LI> * ( = -1, 0, 1 or 2)
   *  </UL>
   *  For more information on the DE-9IM, see the OpenGIS Simple Features
   *  Specification.
   *
   *@param  other                the <code>Geometry</code> with which to compare
   *      this <code>Geometry</code>
   *@param  intersectionPattern  the pattern against which to check the
   *      intersection matrix for the two <code>Geometry</code>s
   *@return                      <code>true</code> if the DE-9IM intersection
   *      matrix for the two <code>Geometry</code>s match <code>intersectionPattern</code>
   */
  boolean relate(Geometry other, String intersectionPattern);

  /**
   *  Returns the DE-9IM intersection matrix for the two <code>Geometry</code>s.
   *
   *@param  other  the <code>Geometry</code> with which to compare this <code>Geometry</code>
   *@return        a matrix describing the intersections of the interiors,
   *      boundaries and exteriors of the two <code>Geometry</code>s
   */
  IntersectionMatrix relate(Geometry other);

  /**
   *  Returns a buffer region around this <code>Geometry</code> having the given
   *  width.
   *
   *@param  distance  the width of the buffer, interpreted according to the
   *      <code>PrecisionModel</code> of the <code>Geometry</code>
   *@return           all points whose distance from this <code>Geometry</code>
   *      are less than or equal to <code>distance</code>
   */
  Geometry buffer(double distance);

  /**
   *  Returns the smallest convex <code>Polygon</code> that contains all the
   *  points in the <code>Geometry</code>. This obviously applies only to <code>Geometry</code>
   *  s which contain 3 or more points; the results for degenerate cases are
   *  specified as follows:
   *  <TABLE>
   *
   *    <TR>
   *
   *      <TH>
   *        Number of <code>Point</code>s in argument <code>Geometry</code>
   *
   *      </TH>
   *
   *      <TH>
   *        <code>Geometry</code> class of result
   *      </TH>
   *
   *    </TR>
   *
   *    <TR>
   *
   *      <TD>
   *        0
   *      </TD>
   *
   *      <TD>
   *        empty <code>GeometryCollection</code>
   *      </TD>
   *
   *    </TR>
   *
   *    <TR>
   *
   *      <TD>
   *        1
   *      </TD>
   *
   *      <TD>
   *        <code>Point</code>
   *      </TD>
   *
   *    </TR>
   *
   *    <TR>
   *
   *      <TD>
   *        2
   *      </TD>
   *
   *      <TD>
   *        <code>LineString</code>
   *      </TD>
   *
   *    </TR>
   *
   *    <TR>
   *
   *      <TD>
   *        3 or more
   *      </TD>
   *
   *      <TD>
   *        <code>Polygon</code>
   *      </TD>
   *
   *    </TR>
   *
   *  </TABLE>
   *
   *
   *@return    the minimum-area convex polygon containing this <code>Geometry</code>'
   *      s points
   */
  Geometry convexHull();

  /**
   *  Returns a <code>Geometry</code> representing the points shared by this
   *  <code>Geometry</code> and <code>other</code>.
   *
   *@param  other  the <code>Geometry</code> with which to compute the
   *      intersection
   *@return        the points common to the two <code>Geometry</code>s
   */
  Geometry intersection(Geometry other);

  /**
   *  Returns a <code>Geometry</code> representing all the points in this <code>Geometry</code>
   *  and <code>other</code>.
   *
   *@param  other  the <code>Geometry</code> with which to compute the union
   *@return        a set combining the points of this <code>Geometry</code> and
   *      the points of <code>other</code>
   */
  Geometry union(Geometry other);

  /**
   *  Returns a <code>Geometry</code> representing the points making up this
   *  <code>Geometry</code> that do not make up <code>other</code>. This method
   *  returns the closure of the resultant <code>Geometry</code>.
   *
   *@param  other  the <code>Geometry</code> with which to compute the
   *      difference
   *@return        the point set difference of this <code>Geometry</code> with
   *      <code>other</code>
   */
  Geometry difference(Geometry other);

  /**
   *  Returns a set combining the points in this <code>Geometry</code> not in
   *  <code>other</code>, and the points in <code>other</code> not in this
   *  <code>Geometry</code>. This method returns the closure of the resultant
   *  <code>Geometry</code>.
   *
   *@param  other  the <code>Geometry</code> with which to compute the symmetric
   *      difference
   *@return        the point set symmetric difference of this <code>Geometry</code>
   *      with <code>other</code>
   */
  Geometry symDifference(Geometry other);

  /**
   *  Returns the Well-known Text representation of this <code>Geometry</code>.
   *  For a definition of the Well-known Text format, see the OpenGIS Simple
   *  Features Specification.
   *
   *@return    the Well-known Text representation of this <code>Geometry</code>
   */
  String toText();
}

