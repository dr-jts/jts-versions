package com.vividsolutions.jts.algorithm;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.2
 */
import com.vividsolutions.jts.geom.*;

public class SimplePointInRing
  implements PointInRing
{

  private static CGAlgorithms cga = new RobustCGAlgorithms();

  private Coordinate[] pts;

  public SimplePointInRing(LinearRing ring)
  {
    pts = ring.getCoordinates();
  }

  public boolean isInside(Coordinate pt)
  {
    return cga.isPointInRing(pt, pts);
  }
}