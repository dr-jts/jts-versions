package com.vividsolutions.jts.util;

public class Stopwatch {

  private long startTime;

  public Stopwatch()
  {
    startTime = System.currentTimeMillis();
  }

  public void start()
  {
    startTime = System.currentTimeMillis();
  }

  public long getTime()
  {
    long endTime = System.currentTimeMillis();
    long totalTime = endTime - startTime;
    return totalTime;
  }

  public String getTimeString()
  {
    long totalTime = getTime();
    String totalTimeStr = totalTime < 10000 ? totalTime + " ms" : (double) totalTime / 1000.0 + " s";
    return totalTimeStr;
  }
}