/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

 package com.vividsolutions.jts.graph.buffer;

/**
 * @version 1.0
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.*;
import com.vividsolutions.jts.algorithm.*;
import com.vividsolutions.jts.graph.*;

/**
 * BufferEdgeBuilder creates all the "rough" edges in the buffer for a Geometry.
 * Rough edges need to be noded together and polygonized to form the final buffer polygon.
 */
public class BufferEdgeBuilder {

  private CGAlgorithms cga;
  private double distance;

  //private BufferMultiLineBuilder lineBuilder;
  private BufferLineBuilder lineBuilder;
  private List edgeList = new ArrayList();

  public BufferEdgeBuilder(CGAlgorithms cga, LineIntersector li, double distance, boolean makePrecise)
  {
    this.cga = cga;
    this.distance = distance;
    //lineBuilder = new BufferMultiLineBuilder(cga, li);
    lineBuilder = new BufferLineBuilder(cga, li, makePrecise);
  }

  public List getEdges(Geometry geom)
  {
    add(geom);
    return edgeList;
  }

  private void addEdges(List lineList, int leftLoc, int rightLoc)
  {
    for (Iterator i = lineList.iterator(); i.hasNext(); ) {
      Coordinate[] coords = (Coordinate[]) i.next();
      addEdge(coords, leftLoc, rightLoc);
    }
  }

  /**
   * Creates an edge for a coordinate list which is a ring of a buffer,
   * and adds it to the list of buffer edges.
   * The ring may be oriented in either direction.
   * If the ring is oriented CW, the locations will be:
   * <br>Left: Location.EXTERIOR
   * <br>Right: Location.INTERIOR
   */
  private void addEdge(Coordinate[] coord, int leftLoc, int rightLoc)
  {
    // don't add null buffers!
    if (coord.length < 2) return;
    // add the edge for a coordinate list which is a ring of a buffer
    Edge e = new Edge(coord,
                        new Label(0, Location.BOUNDARY, leftLoc, rightLoc));
    edgeList.add(e);
  }


  private void add(Geometry g)
  {
    if (g.isEmpty()) return;

    if (g instanceof Polygon)                 addPolygon((Polygon) g);
                        // LineString also handles LinearRings
    else if (g instanceof LineString)         addLineString((LineString) g);
    else if (g instanceof Point)              addPoint((Point) g);
    else if (g instanceof MultiPoint)         addCollection((MultiPoint) g);
    else if (g instanceof MultiLineString)    addCollection((MultiLineString) g);
    else if (g instanceof MultiPolygon)       addCollection((MultiPolygon) g);
    else if (g instanceof GeometryCollection) addCollection((GeometryCollection) g);
    else  throw new UnsupportedOperationException(g.getClass().getName());
  }
  private void addCollection(GeometryCollection gc)
  {
    for (int i = 0; i < gc.getNumGeometries(); i++) {
      Geometry g = gc.getGeometryN(i);
      add(g);
    }
  }
  /**
   * Add a Point to the graph.
   */
  private void addPoint(Point p)
  {
    if (distance <= 0.0) return;
    Coordinate[] coord = p.getCoordinates();
    List lineList = lineBuilder.getLineBuffer(coord, distance);
    addEdges(lineList, Location.EXTERIOR, Location.INTERIOR);
  }
  private void addLineString(LineString line)
  {
    if (distance <= 0.0) return;
    Coordinate[] coord = line.getCoordinates();
    List lineList = lineBuilder.getLineBuffer(coord, distance);
    addEdges(lineList, Location.EXTERIOR, Location.INTERIOR);
  }
  private void addPolygon(Polygon p)
  {
    double lineDistance = distance;
    int side = Position.LEFT;
    if (distance < 0.0) {
      lineDistance = -distance;
      side = Position.RIGHT;
    }
    int holeSide = (side == Position.LEFT) ? Position.RIGHT : Position.LEFT;
    addPolygonRing(
            (LinearRing) p.getExteriorRing(),
            lineDistance,
            side,
            Location.EXTERIOR,
            Location.INTERIOR);

    for (int i = 0; i < p.getNumInteriorRing(); i++) {
      // Holes are topologically labelled opposite to the shell, since
      // the interior of the polygon lies on their opposite side
      // (on the left, if the hole is oriented CCW)
      addPolygonRing(
            (LinearRing) p.getInteriorRingN(i),
            lineDistance,
            Position.opposite(side),
            Location.INTERIOR,
            Location.EXTERIOR);
    }
  }
  /**
   * The side and left and right topological location arguments assume that the ring is oriented CW.
   * If the ring is in the opposite orientation,
   * the left and right locations must be interchanged and the side flipped.
   *
   * @param lr the LinearRing around which to create the buffer
   * @param distance the distance at which to create the buffer
   * @param side the side of the ring on which to construct the buffer line
   * @param cwLeftLoc the location on the L side of the ring (if it is CW)
   * @param cwRightLoc the location on the R side of the ring (if it is CW)
   */
  private void addPolygonRing(LinearRing lr, double distance, int side, int cwLeftLoc, int cwRightLoc)
  {
    Coordinate[] coord = lr.getCoordinates();
    int leftLoc  = cwLeftLoc;
    int rightLoc = cwRightLoc;
    if (cga.isCCW(coord)) {
      leftLoc = cwRightLoc;
      rightLoc = cwLeftLoc;
      side = Position.opposite(side);
    }
    List lineList = lineBuilder.getRingBuffer(coord, side, distance);
    addEdges(lineList, leftLoc, rightLoc);
    /*
    Edge e = new Edge(coord,
                        new Label(0, Location.BOUNDARY, left, right));

    insertEdge(e);
    // insert the endpoint as a node, to mark that it is on the boundary
    insertPoint(argIndex, coord[0], Location.BOUNDARY);
    */
  }




}