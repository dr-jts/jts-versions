/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.graph.reduce;

import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.*;
import com.vividsolutions.jts.algorithm.*;
import com.vividsolutions.jts.graph.*;
import com.vividsolutions.jts.graph.overlay.OverlayGraph;

/**
 * A PrecisionReducer reduces the precison of a Geometry.
 * During this process it is possible that dimensional collapses
 * will occur, and these are handled appropriately.
 * @version 1.0
 */
public class PrecisionReducer {

  private static final Coordinate[] arrayTypeCoordinate = new Coordinate[0];

  private Geometry geom;
  private PrecisionModel newPM;
  private PrecisionModel oldPM;
  private GeometryGraph geomGraph;

  public PrecisionReducer(Geometry geom, PrecisionModel newPM)
  {
    this.geom = geom;
    this.newPM = newPM;
    oldPM = geom.getPrecisionModel();
  }

  public Geometry getResultGeometry()
  {
    Geometry resultGeom = reducePrecision();
    return resultGeom;
  }

  private Geometry reducePrecision()
  {
    GeometryFactory fact = new GeometryFactory(newPM, geom.getSRID());
    Geometry empty = fact.createGeometryCollection(null);
    GeometryGraph emptyGraph = new GeometryGraph(1, empty);

    geomGraph = new GeometryGraph(0, newPM, geom.getSRID());
    add(geom);

    OverlayGraph gov = new OverlayGraph(geomGraph, emptyGraph);
    Geometry geomOv = gov.getResultGeometry(OverlayGraph.UNION);
    return geomOv;
  }

  private void add(Geometry g)
  {
    if (g.isEmpty()) return;

    if (g instanceof Polygon)                 addPolygon((Polygon) g);
                        // LineString also handles LinearRings
    else if (g instanceof LineString)         addLineString((LineString) g);
    else if (g instanceof Point)              addPoint((Point) g);
    else if (g instanceof MultiPoint)         addCollection((MultiPoint) g);
    else if (g instanceof MultiLineString)    addCollection((MultiLineString) g);
    else if (g instanceof MultiPolygon)       addCollection((MultiPolygon) g);
    else if (g instanceof GeometryCollection) addCollection((GeometryCollection) g);
    else  throw new UnsupportedOperationException(g.getClass().getName());
  }
  private void addCollection(GeometryCollection gc)
  {
    for (int i = 0; i < gc.getNumGeometries(); i++) {
      Geometry g = gc.getGeometryN(i);
      add(g);
    }
  }
  /**
   * Add a Point to the graph.
   */
  private void addPoint(Point p)
  {
    addPoint(p.getCoordinate());
  }

  /**
   * The left and right topological location arguments assume that the ring is oriented CW.
   * If the ring is in the opposite orientation,
   * the left and right locations must be interchanged.
   */
  private void addPolygonRing(LinearRing lr, int cwLeft, int cwRight)
  {
    Coordinate[] coord = lr.getCoordinates();
    int left  = cwLeft;
    int right = cwRight;
    if (Graph.cga.isCCW(coord)) {
      left = cwRight;
      right = cwLeft;
    }
    addEdge(coord, new Label(0, Location.BOUNDARY, left, right));
  }

  private void addPolygon(Polygon p)
  {
    addPolygonRing(
            (LinearRing)p.getExteriorRing(),
            Location.EXTERIOR,
            Location.INTERIOR);

    for (int i = 0; i < p.getNumInteriorRing(); i++) {
      // Holes are topologically labelled opposite to the shell, since
      // the interior of the polygon lies on their opposite side
      // (on the left, if the hole is oriented CW)
      addPolygonRing(
            (LinearRing)p.getInteriorRingN(i),
            Location.INTERIOR,
            Location.EXTERIOR);
    }
  }

  private void addLineString(LineString line)
  {
    addEdge(line.getCoordinates(), new Label(0, Location.INTERIOR));
  }

  private void addEdge(Coordinate[] coords, Label lbl)
  {
    Coordinate[] reduceCoord = changePrecision(coords);
    if (reduceCoord.length > 1) {
      Edge e = new Edge(reduceCoord, lbl);
      geomGraph.addEdge(e);
    }
    else {
      addPoint(coords[0]);
    }
  }

  private void addPoint(Coordinate coord)
  {
    geomGraph.addPoint(changePrecision(coord));
  }
  private Coordinate[] changePrecision(Coordinate[] coords)
  {
    List ptList = new ArrayList();
    Coordinate prevCoord = null;
    for (int i = 0; i < coords.length; i++) {
      Coordinate newCoord = changePrecision(coords[i]);
      if (prevCoord == null || ! prevCoord.equals(newCoord)) {
        ptList.add(newCoord);
      }
      prevCoord = newCoord;
    }
    Coordinate[] newCoords = (Coordinate[]) ptList.toArray(arrayTypeCoordinate);
    return newCoords;
  }
  private Coordinate changePrecision(Coordinate coord)
  {
    Coordinate newCoord = new Coordinate();
    oldPM.toExternal(coord, newCoord);
    newPM.toInternal(newCoord, newCoord);
    return newCoord;
  }




}