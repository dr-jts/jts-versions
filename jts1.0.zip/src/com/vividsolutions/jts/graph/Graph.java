/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.graph;

/**
 * @version 1.0
 */
import java.io.PrintStream;
import java.util.*;
import com.vividsolutions.jts.util.*;
import com.vividsolutions.jts.algorithm.*;
import com.vividsolutions.jts.geom.*;

/**
 * The computation of the <code>IntersectionMatrix</code> relies on the use of a structure
 * called a "topology graph".  The topology graph contains nodes and edges
 * corresponding to the nodes and line segments of a <code>Geometry</code>. Each
 * node and edge in the graph is labeled with its topological location relative to
 * the source geometry.
 * <P>
 * Note that there is no requirement that points of self-intersection be a vertex.
 * Thus to obtain a correct topology graph, <code>Geometry</code>s must be
 * self-noded before constructing their graphs.
 * <P>
 * Two fundamental operations are supported by topology graphs:
 * <UL>
 *   <LI>Computing the intersections between all the edges and nodes of a single graph
 *   <LI>Computing the intersections between the edges and nodes of two different graphs
 * </UL>
 */
public class Graph {

/**
 * This method implements the Boundary Determination Rule
 * for determining whether
 * a component (node or edge) that appears multiple times in elements
 * of a MultiGeometry is in the boundary or the interior of the Geometry
 * <br>
 * The SFS uses the "Mod-2 Rule", which this function implements
 * <br>
 * An alternative (and possibly more intuitive) rule would be
 * the "At Most One Rule":
 *    isInBoundary = (componentCount == 1)
 */
  public static boolean isInBoundary(int boundaryCount)
  {
    // the "Mod-2 Rule"
    return boundaryCount % 2 == 1;
  }
  public static int determineBoundary(int boundaryCount)
  {
    return isInBoundary(boundaryCount) ? Location.BOUNDARY : Location.INTERIOR;
  }

  public static final CGAlgorithms cga = new RobustCGAlgorithms();
  public static final LineIntersector li = new RobustLineIntersector();

  protected String name;

  protected List edges = new ArrayList();
  protected NodeMap nodes;

  public Graph() {
  }

  public void setName(String name) { this.name = name; }
  public Iterator getEdgeIterator() { return edges.iterator(); }

  public boolean isBoundaryNode(int geomIndex, Coordinate coord)
  {
    Node node = nodes.find(coord);
    if (node == null) return false;
    Label label = node.getLabel();
    if (label != null && label.getLocation(geomIndex) == Location.BOUNDARY) return true;
    return false;
  }
  protected void insertEdge(Edge e)
  {
    e.setName(name + edges.size());
    edges.add(e);
  }

  public Iterator getNodeIterator() { return nodes.iterator(); }
  public NodeMap getNodes() { return nodes; }

  public void printEdges(PrintStream out)
  {
    out.println("Edges:");
    for (int i = 0; i < edges.size(); i++) {
      out.println("edge " + i + ":");
      Edge e = (Edge) edges.get(i);
      e.print(out);
      e.eiList.print(out);
    }
  }
  void debugPrint(Object o)
  {
    System.out.print(o);
  }
  void debugPrintln(Object o)
  {
    System.out.println(o);
  }

}
