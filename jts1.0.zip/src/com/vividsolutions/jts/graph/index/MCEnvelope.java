/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.graph.index;

/**
 * @version 1.0
 */
import com.vividsolutions.jts.geom.Coordinate;

public class MCEnvelope {

  double minx, maxx, miny, maxy;

  public MCEnvelope() {
    minx = 0;
    maxx = -1;
    miny = 0;
    maxy = -1;
  }

  public void init(Coordinate p1, Coordinate p2)
  {
    minx = (p1.x < p2.x) ? p1.x : p2.x;
    maxx = (p1.x > p2.x) ? p1.x : p2.x;
    miny = (p1.y < p2.y) ? p1.y : p2.y;
    maxy = (p1.y > p2.y) ? p1.y : p2.y;
  }

  public void init(Coordinate p)
  {
    minx = p.x;
    maxx = p.x;
    miny = p.y;
    maxy = p.y;
  }

  private void init(MCEnvelope env)
  {
    minx = env.minx;
    maxx = env.maxx;
    miny = env.miny;
    maxy = env.maxx;
  }

  public boolean overlaps(MCEnvelope env)
  {
    return ! (env.minx > maxx ||
              env.maxx < minx ||
              env.miny > maxy ||
              env.maxy < miny     );
  }

  public boolean isNull() { return maxx < minx; }

  public void expand(Coordinate p) {
    if (isNull()) {
      init(p);
    }
    else {
      minx = minx < p.x ? minx : p.x;
      maxx = maxx > p.x ? maxx : p.x;
      miny = miny < p.y ? miny : p.y;
      maxy = maxy > p.y ? maxy : p.y;
    }
  }

  public void expand(MCEnvelope env) {
    if (env.isNull()) return;
    if (isNull()) {
      init(env);
    }
    else {
      minx = minx < env.minx ? minx : env.minx;
      maxx = maxx > env.maxx ? maxx : env.maxx;
      miny = miny < env.miny ? miny : env.miny;
      maxy = maxy > env.maxy ? maxy : env.maxy;
    }
  }

}
