/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */

package com.vividsolutions.jts.graph.index;

/**
 * A NonReversingChainEdge is a contiguous subset of the Monotone Chains of an Edge
 * which has the property that the direction vectors of each segment lie in the same
 * half plane.  This implies the property:
 * <ol>
 * <li>the segments in the set never intersect
 * one another (since the edges never "curl back" on themselves).
 * </ol>
 * Property 1 means that there is no need to test pairs of segments from within
 * the same NonReversingEdge for intersection.
 * This reduces the number of segment comparisons needed to test for edge intersection.
 * @version 1.0
 */
import java.util.*;
import com.vividsolutions.jts.algorithm.LineIntersector;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.graph.*;
import com.vividsolutions.jts.util.*;

public class NonReversingChainEdge {

  Coordinate[] pts;
  MonotoneChainEdge mce;
  // the list of start/end indexes of the non-reversing sections.
  // Note these are indexes into the MonotoneChainEdge's startList.
  // Includes the last index as a sentinel.
  int[] startIndex;
  int[] mceStartIndex;
  MCEnvelope[] env;   // the envelopes of the non-reversing chains

  public NonReversingChainEdge(MonotoneChainEdge mce)
  {
    this.mce = mce;
    pts = mce.getCoordinates();
    init();
  }

  private void init()
  {
    mceStartIndex = mce.getStartIndexes();

    // find the startpoint (and endpoints) of all non-reversing chains in this edge
    int start = 0;
    List startIndexList = new ArrayList();
    startIndexList.add(new Integer(start));
    do {
      int last = findNextChainIndex(start);
      startIndexList.add(new Integer(last));
      start = last;
    } while (start < mceStartIndex.length - 1);
    // copy list to an array of ints, for efficiency
    startIndex = MonotoneChainEdge.toIntArray(startIndexList);
    computeEnvelopes();
  }

  private void computeEnvelopes()
  {
    env = new MCEnvelope[startIndex.length - 1];
    for (int i = 0; i < env.length; i++) {
      MCEnvelope chainEnv = new MCEnvelope();
      int start = startIndex[i];
      int end = startIndex[i + 1];
      // expand the envelope to include the envelope of each monotone chain
      for (int j = start; j < end; j++) {
        // the envelope of a monotone chain is the envelope of the endpoints
        chainEnv.expand(pts[mceStartIndex[j]]);
        chainEnv.expand(pts[mceStartIndex[j + 1]]);
      }
      env[i] = chainEnv;
    }
  }

  /**
   * @return the index of the start of the next non-reversing chain
   */
  private int findNextChainIndex(int start)
  {
    // determine quadrant for chain
    int startQuad = Quadrant.quadrant(pts[mceStartIndex[start]], pts[mceStartIndex[start] + 1]);
    int chainHalfPlane = -1;
    int last = start + 1;
    while (last < mceStartIndex.length - 1) {
      int quad = Quadrant.quadrant( pts[ mceStartIndex[last] ],
                                    pts[ mceStartIndex[last] + 1 ] );
      // if this is the second chain examined
      if (chainHalfPlane < 0) {
        if (quad == startQuad)
          Assert.shouldNeverReachHere();
        if (Quadrant.isOpposite(startQuad, quad)) break;
        chainHalfPlane = Quadrant.commonHalfPlane(startQuad, quad);
      }
      else {
        if (! Quadrant.isInHalfPlane(quad, chainHalfPlane)) break;
      }
      last++;
    }
    return last;
  }

  public void computeIntersects(NonReversingChainEdge nre, SegmentIntersector si)
  {
    for (int i = 0; i < startIndex.length - 1; i++) {
      for (int j = 0; j < nre.startIndex.length - 1; j++) {
        computeIntersectsForChain(i, nre, j, si);
      }
    }
  }

  private void computeIntersectsForChain(
    int chainIndex0,
    NonReversingChainEdge nre,
    int chainIndex1,
    SegmentIntersector si)
  {
    MCEnvelope env0 = env[chainIndex0];
    MCEnvelope env1 = env[chainIndex1];
    if (env0.overlaps(env1)) {
      // compare all monotone chains in the two non-reversing chains
      for (int mc0Index = startIndex[chainIndex0]; mc0Index < startIndex[chainIndex0 + 1]; mc0Index++) {
        for (int mc1Index = nre.startIndex[chainIndex1]; mc1Index < nre.startIndex[chainIndex1 + 1]; mc1Index++) {
          mce.computeIntersectsForChain(mc0Index, nre.mce, mc1Index, si);
        }
      }
    }
  }
}
