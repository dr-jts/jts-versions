/*
 * The Java Topology Suite (JTS) is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.graph;

/**
 * @version 1.0
 */
import com.vividsolutions.jts.geom.PrecisionModel;
import com.vividsolutions.jts.geom.*;

public class ResultGraph
  extends Graph
{
  /**
   * Put the relate args into an array, so we can access them by index
   */
  protected GeometryGraph[] arg;  // the arg(s) of the relate operator
  protected boolean makePrecise;

  public ResultGraph(GeometryGraph g0, GeometryGraph g1) {
    setComputationPrecision(g0.getPrecisionModel());
    g0.setName("A");
    g1.setName("B");

    arg = new GeometryGraph[2];
    arg[0] = g0;
    arg[1] = g1;
  }
  public ResultGraph(GeometryGraph g0) {
    setComputationPrecision(g0.getPrecisionModel());
    g0.setName("A");

    arg = new GeometryGraph[1];
    arg[0] = g0;
  }
  public Geometry getInputGeometry(int i) { return arg[i].getGeometry(); }

  protected void setComputationPrecision(PrecisionModel pm)
  {
    makePrecise = ! pm.isFloating();
    li.setMakePrecise(makePrecise);
  }
}