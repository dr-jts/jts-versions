package com.vividsolutions.jts.example;

import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.io.*;

/**
 * This example demonstrates using JTS with a fixed precision model
 *
 * The output from this program is:
 * ----------------------------------------------------------
 * c = LINESTRING (40 73, 80 60, 90 100)
 * a relate c = 1F2F01FF2
 * ----------------------------------------------------------
 */
public class Example1
{
  static PrecisionModel pm = new PrecisionModel(1, 0, 0);
  static GeometryFactory fact = new GeometryFactory(pm, 0);
  static WKTReader wktRdr = new WKTReader(fact);
  static WKTWriter wktWriter = new WKTWriter();

  public static void main(String[] args) {
    Example1 example = new Example1();
    try {
      example.run();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public Example1() {
  }

  public void run()
    throws ParseException
  {
      String wktA = "POLYGON((40 100, 40 20, 120 20, 120 100, 40 100))";
      String wktB = "LINESTRING(20 80, 80 60, 100 140)";
      Geometry a = wktRdr.read(wktA);
      Geometry b = wktRdr.read(wktB);
      Geometry c = a.intersection(b);
      System.out.println("c = " + wktWriter.write(c));
      System.out.println("a relate c = " + a.relate(c));
  }

}