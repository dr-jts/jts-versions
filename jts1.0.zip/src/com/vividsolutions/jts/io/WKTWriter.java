/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.io;

import com.vividsolutions.jts.geom.*;

import com.vividsolutions.jts.util.Assert;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.text.DecimalFormat;

/**
/**
 *  The Well-Known Text Writer outputs the textual representation of a <code>Geometry object</code>
 *  . The Well-known Text format is defined in the <A
 *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
 *  Specification for SQL</A> .
 *
 *  The <code>WKTWriter</code> will output coordinates rounded to the
 *  precision model. No more than the maximum number of necessary decimal places
 *  will be output.
 *
 *@version 1.0
 */
public class WKTWriter {

  private static int INDENT = 2;
  /**
   *  Creates the <code>DecimalFormat</code> used to write <code>double</code>s
   *  with a sufficient number of decimal places.
   *
   *@param  precisionModel  the <code>PrecisionModel</code> used to determine
   *      the number of decimal places to write.
   *@return                 a <code>DecimalFormat</code> that write <code>double</code>
   *      s without scientific notation.
   */
  private static DecimalFormat createFormatter(PrecisionModel precisionModel) {
    // the default number of decimal places is 16, which is sufficient
    // to accomodate the maximum precision of a double.
    int decimalPlaces = 16;
    if (! precisionModel.isFloating()) {
      decimalPlaces = 1 + (int) Math.ceil(Math.log(precisionModel.getScale()) / Math.log(10));
    }
    return new DecimalFormat("#" + (decimalPlaces > 0 ? "." : "")
         + stringOfChar('#', decimalPlaces));
  }

  /**
   *  Converts <code>double</code>s to <code>String</code>s, without scientific
   *  notation.
   */
  protected DecimalFormat formatter;
  private boolean isFormatted = false;
  private int level = 0;

  /**
   *  Returns a <code>String</code> of repeated characters.
   *
   *@param  ch     the character to repeat
   *@param  count  the number of times to repeat the character
   *@return        a <code>String</code> of characters
   */
  public static String stringOfChar(char ch, int count) {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < count; i++) {
      buf.append(ch);
    }
    return buf.toString();
  }

  public WKTWriter()
  {
  }

  /**
   *  Converts a <code>Geometry</code> to its Well-known Text representation.
   *
   *@param  geometry  a <code>Geometry</code> to process
   *@return           a <Geometry Tagged Text> string (see the OpenGIS Simple
   *      Features Specification)
   */
  public String write(Geometry geometry) {
    return writeFormatted(geometry, false);
  }

  /**
   *  Same as <code>write</code>, but with newlines and spaces to make the
   *  well-known text more readable.
   *
   *@param  geometry  a <code>Geometry</code> to process
   *@return           a <Geometry Tagged Text> string (see the OpenGIS Simple
   *      Features Specification), with newlines and spaces
   */
  public String writeFormatted(Geometry geometry) {
    return writeFormatted(geometry, true);
  }
  /**
   *  Converts a <code>Geometry</code> to its Well-known Text representation.
   *
   *@param  geometry  a <code>Geometry</code> to process
   *@return           a <Geometry Tagged Text> string (see the OpenGIS Simple
   *      Features Specification)
   */
  private String writeFormatted(Geometry geometry, boolean isFormatted) {
    this.isFormatted = isFormatted;
    formatter = createFormatter(geometry.getPrecisionModel());
    StringBuffer buffer = new StringBuffer();
    appendGeometryTaggedText(geometry, 0, buffer);
    return buffer.toString();
  }


  /**
   *  Converts a <code>Geometry</code> to &lt;Geometry Tagged Text&gt; format,
   *  then appends it to the buffer.
   *
   *@param  geometry  the <code>Geometry</code> to process
   *@param  buffer    the output buffer to append to
   */
  protected void appendGeometryTaggedText(Geometry geometry, int level, StringBuffer buffer)
  {
    indent(level, buffer);

    if (geometry instanceof Point) {
      Point point = (Point) geometry;
      appendPointTaggedText(point.getCoordinate(), level, buffer, point.getPrecisionModel());
    }
    else if (geometry instanceof LineString) {
      appendLineStringTaggedText((LineString) geometry, level, buffer);
    }
    else if (geometry instanceof Polygon) {
      appendPolygonTaggedText((Polygon) geometry, level, buffer);
    }
    else if (geometry instanceof MultiPoint) {
      appendMultiPointTaggedText((MultiPoint) geometry, level, buffer);
    }
    else if (geometry instanceof MultiLineString) {
      appendMultiLineStringTaggedText((MultiLineString) geometry, level, buffer);
    }
    else if (geometry instanceof MultiPolygon) {
      appendMultiPolygonTaggedText((MultiPolygon) geometry, level, buffer);
    }
    else if (geometry instanceof GeometryCollection) {
      appendGeometryCollectionTaggedText((GeometryCollection) geometry, level, buffer);
    }
    else {
      Assert.shouldNeverReachHere("Unsupported Geometry implementation:"
           + geometry.getClass());
    }
  }

  /**
   *  Converts a <code>Coordinate</code> to &lt;Point Tagged Text&gt; format,
   *  then appends it to the buffer.
   *
   *@param  coordinate      the <code>Coordinate</code> to process
   *@param  buffer          the output buffer to append to
   *@param  precisionModel  the <code>PrecisionModel</code> to use to convert
   *      from a precise coordinate to an external coordinate
   */
  protected void appendPointTaggedText(Coordinate coordinate, int level, StringBuffer buffer,
      PrecisionModel precisionModel) {
    buffer.append("POINT ");
    appendPointText(coordinate, level, buffer, precisionModel);
  }

  /**
   *  Converts a <code>LineString</code> to &lt;LineString Tagged Text&gt;
   *  format, then appends it to the buffer.
   *
   *@param  lineString  the <code>LineString</code> to process
   *@param  buffer      the output buffer to append to
   */
  protected void appendLineStringTaggedText(LineString lineString, int level, StringBuffer buffer) {
    buffer.append("LINESTRING ");
    appendLineStringText(lineString, level, false, buffer);
  }

  /**
   *  Converts a <code>Polygon</code> to &lt;Polygon Tagged Text&gt; format,
   *  then appends it to the buffer.
   *
   *@param  polygon  the <code>Polygon</code> to process
   *@param  buffer   the output buffer to append to
   */
  protected void appendPolygonTaggedText(Polygon polygon, int level, StringBuffer buffer) {
    buffer.append("POLYGON ");
    appendPolygonText(polygon, level, false, buffer);
  }

  /**
   *  Converts a <code>MultiPoint</code> to &lt;MultiPoint Tagged Text&gt;
   *  format, then appends it to the buffer.
   *
   *@param  multipoint  the <code>MultiPoint</code> to process
   *@param  buffer      the output buffer to append to
   */
  protected void appendMultiPointTaggedText(MultiPoint multipoint, int level, StringBuffer buffer) {
    buffer.append("MULTIPOINT ");
    appendMultiPointText(multipoint, level, buffer);
  }

  /**
   *  Converts a <code>MultiLineString</code> to &lt;MultiLineString Tagged
   *  Text&gt; format, then appends it to the buffer.
   *
   *@param  multiLineString  the <code>MultiLineString</code> to process
   *@param  buffer           the output buffer to append to
   */
  protected void appendMultiLineStringTaggedText(MultiLineString multiLineString, int level,
      StringBuffer buffer) {
    buffer.append("MULTILINESTRING ");
    appendMultiLineStringText(multiLineString, level, false, buffer);
  }

  /**
   *  Converts a <code>MultiPolygon</code> to &lt;MultiPolygon Tagged Text&gt;
   *  format, then appends it to the buffer.
   *
   *@param  multiPolygon  the <code>MultiPolygon</code> to process
   *@param  buffer        the output buffer to append to
   */
  protected void appendMultiPolygonTaggedText(MultiPolygon multiPolygon, int level, StringBuffer buffer)
  {
    buffer.append("MULTIPOLYGON ");
    appendMultiPolygonText(multiPolygon, level, buffer);
  }

  /**
   *  Converts a <code>GeometryCollection</code> to &lt;GeometryCollection
   *  Tagged Text&gt; format, then appends it to the buffer.
   *
   *@param  geometryCollection  the <code>GeometryCollection</code> to process
   *@param  buffer              the output buffer to append to
   */
  protected void appendGeometryCollectionTaggedText(GeometryCollection geometryCollection, int level,
      StringBuffer buffer) {
    buffer.append("GEOMETRYCOLLECTION ");
    appendGeometryCollectionText(geometryCollection, level, buffer);
  }

  /**
   *  Converts a <code>Coordinate</code> to &lt;Point Text&gt; format, then
   *  appends it to the buffer.
   *
   *@param  coordinate      the <code>Coordinate</code> to process
   *@param  buffer          the output buffer to append to
   *@param  precisionModel  the <code>PrecisionModel</code> to use to convert
   *      from a precise coordinate to an external coordinate
   */
  protected void appendPointText(Coordinate coordinate, int level, StringBuffer buffer,
      PrecisionModel precisionModel) {
    if (coordinate == null) {
      buffer.append("EMPTY");
    }
    else {
      buffer.append("(");
      appendCoordinate(coordinate, buffer, precisionModel);
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>Coordinate</code> to &lt;Point&gt; format, then appends
   *  it to the buffer.
   *
   *@param  coordinate      the <code>Coordinate</code> to process
   *@param  buffer          the output buffer to append to
   *@param  precisionModel  the <code>PrecisionModel</code> to use to convert
   *      from a precise coordinate to an external coordinate
   */
  protected void appendCoordinate(Coordinate coordinate, StringBuffer buffer, PrecisionModel precisionModel) {
    Coordinate externalCoordinate = new Coordinate();
    precisionModel.toExternal(coordinate, externalCoordinate);
    buffer.append(writeNumber(externalCoordinate.x) + " " + writeNumber(externalCoordinate.y));
  }

  /**
   *  Converts a <code>double</code> to a <code>String</code>, not in scientific
   *  notation.
   *
   *@param  d  the <code>double</code> to convert
   *@return    the <code>double</code> as a <code>String</code>, not in
   *      scientific notation
   */
  protected String writeNumber(double d) {
    return formatter.format(d);
  }

  /**
   *  Converts a <code>LineString</code> to &lt;LineString Text&gt; format, then
   *  appends it to the buffer.
   *
   *@param  lineString  the <code>LineString</code> to process
   *@param  buffer      the output buffer to append to
   */
  protected void appendLineStringText(LineString lineString, int level, boolean doIndent, StringBuffer buffer) {
    if (lineString.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      if (doIndent) indent(level, buffer);
      buffer.append("(");
      for (int i = 0; i < lineString.getNumPoints(); i++) {
        if (i > 0) {
          buffer.append(", ");
          if (i % 10 == 0) indent(level + 2, buffer);
        }
        appendCoordinate(lineString.getCoordinateN(i), buffer, lineString.getPrecisionModel());
      }
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>Polygon</code> to &lt;Polygon Text&gt; format, then
   *  appends it to the buffer.
   *
   *@param  polygon  the <code>Polygon</code> to process
   *@param  buffer   the output buffer to append to
   */
  protected void appendPolygonText(Polygon polygon, int level, boolean indentFirst, StringBuffer buffer) {
    if (polygon.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      if (indentFirst) indent(level, buffer);
      buffer.append("(");
      appendLineStringText(polygon.getExteriorRing(), level, false, buffer);
      for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        buffer.append(", ");
        appendLineStringText(polygon.getInteriorRingN(i), level + 1, true, buffer);
      }
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>MultiPoint</code> to &lt;MultiPoint Text&gt; format, then
   *  appends it to the buffer.
   *
   *@param  multiPoint  the <code>MultiPoint</code> to process
   *@param  buffer      the output buffer to append to
   */
  protected void appendMultiPointText(MultiPoint multiPoint, int level, StringBuffer buffer) {
    if (multiPoint.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      buffer.append("(");
      for (int i = 0; i < multiPoint.getNumGeometries(); i++) {
        if (i > 0) {
          buffer.append(", ");
        }
        appendCoordinate(((Point) multiPoint.getGeometryN(i)).getCoordinate(), buffer,
            multiPoint.getPrecisionModel());
      }
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>MultiLineString</code> to &lt;MultiLineString Text&gt;
   *  format, then appends it to the buffer.
   *
   *@param  multiLineString  the <code>MultiLineString</code> to process
   *@param  buffer           the output buffer to append to
   */
  protected void appendMultiLineStringText(MultiLineString multiLineString, int level, boolean indentFirst,
      StringBuffer buffer) {
    if (multiLineString.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      int level2 = level;
      boolean doIndent = indentFirst;
      buffer.append("(");
      for (int i = 0; i < multiLineString.getNumGeometries(); i++) {
        if (i > 0) {
          buffer.append(", ");
          level2 = level + 1;
          doIndent = true;
        }
        appendLineStringText((LineString) multiLineString.getGeometryN(i), level2, doIndent, buffer);
      }
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>MultiPolygon</code> to &lt;MultiPolygon Text&gt; format,
   *  then appends it to the buffer.
   *
   *@param  multiPolygon  the <code>MultiPolygon</code> to process
   *@param  buffer        the output buffer to append to
   */
  protected void appendMultiPolygonText(MultiPolygon multiPolygon, int level, StringBuffer buffer) {
    if (multiPolygon.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      int level2 = level;
      boolean doIndent = false;
      buffer.append("(");
      for (int i = 0; i < multiPolygon.getNumGeometries(); i++) {
        if (i > 0) {
          buffer.append(", ");
          level2 = level + 1;
          doIndent = true;
        }
        appendPolygonText((Polygon) multiPolygon.getGeometryN(i), level2, doIndent, buffer);
      }
      buffer.append(")");
    }
  }

  /**
   *  Converts a <code>GeometryCollection</code> to &lt;GeometryCollectionText&gt;
   *  format, then appends it to the buffer.
   *
   *@param  geometryCollection  the <code>GeometryCollection</code> to process
   *@param  buffer              the output buffer to append to
   */
  protected void appendGeometryCollectionText(GeometryCollection geometryCollection, int level,
      StringBuffer buffer) {
    if (geometryCollection.isEmpty()) {
      buffer.append("EMPTY");
    }
    else {
      int level2 = level;
      buffer.append("(");
      for (int i = 0; i < geometryCollection.getNumGeometries(); i++) {
        if (i > 0) {
          buffer.append(", ");
          level2 = level + 1;
        }
        appendGeometryTaggedText(geometryCollection.getGeometryN(i), level2, buffer);
      }
      buffer.append(")");
    }
  }

  private void indent(int level, StringBuffer buffer)
  {
    if (! isFormatted || level <= 0) return;
    buffer.append("\n");
    buffer.append(stringOfChar(' ', INDENT * level));
  }


}

