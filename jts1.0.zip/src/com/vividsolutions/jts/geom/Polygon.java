/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.geom.sfs.SFSPolygon;
import com.vividsolutions.jts.algorithm.ConvexHull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *  Basic implementation of <code>Polygon</code>.
 *
 *@version 1.0
 */
public class Polygon extends Geometry implements SFSPolygon {
  /**
   *  The exterior boundary, or <code>null</code> if this <code>Polygon</code>
   *  is the empty geometry.
   */
  protected LinearRing shell = null;

  /**
   *  The interior boundaries, if any.
   */
  protected LinearRing[] holes;

  /**
   *  Constructs a <code>Polygon</code> with the given exterior boundary.
   *  The shell and holes must conform to the assertions specified in the <A
   *  HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
   *  Specification for SQL</A> .
   *
   *@param  shell           the outer boundary of the new <code>Polygon</code>,
   *      or <code>null</code> or an empty <code>LinearRing</code> if the empty
   *      geometry is to be created. Must be oriented clockwise.
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>Polygon</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>Polygon</code>
   */
  public Polygon(LinearRing shell, PrecisionModel precisionModel, int SRID) {
    this(shell, new LinearRing[]{}, precisionModel, SRID);
  }

  /**
   *  Constructs a <code>Polygon</code> with the given exterior boundary and
   *  interior boundaries.
   *
   *@param  shell           the outer boundary of the new <code>Polygon</code>,
   *      or <code>null</code> or an empty <code>LinearRing</code> if the empty
   *      geometry is to be created. Must be oriented clockwise.
   *@param  holes           the inner boundaries of the new <code>Polygon</code>
   *      , or <code>null</code> or empty <code>LinearRing</code>s if the empty
   *      geometry is to be created. Each must be oriented counterclockwise.
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>Polygon</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>Polygon</code>
   */
  public Polygon(LinearRing shell, LinearRing[] holes, PrecisionModel precisionModel, int SRID) {
    super(precisionModel, SRID);
    if (shell == null) {
      shell = new LinearRing(null, precisionModel, SRID);
    }
    if (holes == null) {
      holes = new LinearRing[]{};
    }
    if (hasNullElements(holes)) {
      throw new IllegalArgumentException("holes must not contain null elements");
    }
    if (shell.isEmpty() && hasNonEmptyElements(holes)) {
      throw new IllegalArgumentException("shell is empty but holes are not");
    }
    this.shell = shell;
    this.holes = holes;
  }

  public Coordinate[] getCoordinates() {
    if (isEmpty()) {
      return new Coordinate[]{};
    }
    Coordinate[] coordinates = new Coordinate[getNumPoints()];
    int k = -1;
    Coordinate[] shellCoordinates = shell.getCoordinates();
    for (int x = 0; x < shellCoordinates.length; x++) {
      k++;
      coordinates[k] = shellCoordinates[x];
    }
    for (int i = 0; i < holes.length; i++) {
      Coordinate[] childCoordinates = holes[i].getCoordinates();
      for (int j = 0; j < childCoordinates.length; j++) {
        k++;
        coordinates[k] = childCoordinates[j];
      }
    }
    return coordinates;
  }

  public int getNumPoints() {
    int numPoints = shell.getNumPoints();
    for (int i = 0; i < holes.length; i++) {
      numPoints += holes[i].getNumPoints();
    }
    return numPoints;
  }

  public int getDimension() {
    return 2;
  }

  public int getBoundaryDimension() {
    return 1;
  }

  public boolean isEmpty() {
    return shell.isEmpty();
  }

  public boolean isSimple() {
    return true;
  }

  public LineString getExteriorRing() {
    return shell;
  }

  public int getNumInteriorRing() {
    return holes.length;
  }

  public LineString getInteriorRingN(int n) {
    return holes[n];
  }

  public String getGeometryType() {
    return "Polygon";
  }

  public Geometry getBoundary() {
    if (isEmpty()) {
      return new GeometryCollection(null, precisionModel, SRID);
    }
    LinearRing[] rings = new LinearRing[holes.length + 1];
    rings[0] = shell;
    for (int i = 0; i < holes.length; i++) {
      rings[i + 1] = holes[i];
    }
    return new MultiLineString(rings, precisionModel, SRID);
  }

  public Envelope computeEnvelopeInternal() {
    return shell.getEnvelopeInternal();
  }

  public boolean equalsExact(Geometry other) {
    if (!isEquivalentClass(other)) {
      return false;
    }
    Polygon otherPolygon = (Polygon) other;
    if (!(shell instanceof Geometry)) {
      return false;
    }
    Geometry thisShell = shell;
    if (!(otherPolygon.shell instanceof Geometry)) {
      return false;
    }
    Geometry otherPolygonShell = otherPolygon.shell;
    if (!thisShell.equalsExact(otherPolygonShell)) {
      return false;
    }
    if (holes.length != otherPolygon.holes.length) {
      return false;
    }
    if (holes.length != otherPolygon.holes.length) {
      return false;
    }
    for (int i = 0; i < holes.length; i++) {
      if (!(holes[i] instanceof Geometry)) {
        return false;
      }
      if (!(otherPolygon.holes[i] instanceof Geometry)) {
        return false;
      }
      if (!((Geometry) holes[i]).equalsExact((Geometry) otherPolygon.holes[i])) {
        return false;
      }
    }
    return true;
  }

  public void apply(CoordinateFilter filter) {
    shell.apply(filter);
    for (int i = 0; i < holes.length; i++) {
      holes[i].apply(filter);
    }
  }

  public void apply(GeometryFilter filter) {
    filter.filter(this);
  }

  public Object clone() {
    Polygon poly = (Polygon) super.clone();
    poly.shell = (LinearRing) shell.clone();
    poly.holes = new LinearRing[holes.length];
    for (int i = 0; i < holes.length; i++) {
      poly.holes[i] = (LinearRing) holes[i].clone();
    }
    return poly;// return the clone
  }

  public Geometry convexHull() {
    return getExteriorRing().convexHull();
  }

  public void normalize() {
    normalize(shell, true);
    for (int i = 0; i < holes.length; i++) {
      normalize(holes[i], false);
    }
    Arrays.sort(holes);
  }

  protected int compareToSameClass(Object o) {
    LinearRing thisShell = shell;
    LinearRing otherShell = ((Polygon) o).shell;
    return thisShell.compareToSameClass(otherShell);
  }

  private void normalize(LinearRing ring, boolean clockwise) {
    if (ring.isEmpty()) {
      return;
    }
    Coordinate[] uniqueCoordinates = new Coordinate[ring.getCoordinates().length - 1];
    System.arraycopy(ring.getCoordinates(), 0, uniqueCoordinates, 0, uniqueCoordinates.length);
    Coordinate minCoordinate = minCoordinate(ring.getCoordinates());
    scroll(uniqueCoordinates, minCoordinate);
    System.arraycopy(uniqueCoordinates, 0, ring.getCoordinates(), 0, uniqueCoordinates.length);
    ring.getCoordinates()[uniqueCoordinates.length] = uniqueCoordinates[0];
    if (cgAlgorithms.isCCW(ring.getCoordinates()) == clockwise) {
      reversePointOrder(ring.getCoordinates());
    }
  }

}

