/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.geom.sfs.SFSMultiPolygon;

import com.vividsolutions.jts.util.Assert;
import java.util.ArrayList;

/**
 *  Basic implementation of <code>MultiPolygon</code>.
 *
 *@version 1.0
 */
public class MultiPolygon extends GeometryCollection implements SFSMultiPolygon {

  /**
   *  Constructs a <code>MultiPolygon</code>.
   *
   *@param  polygons        the <code>Polygon</code>s for this <code>MultiPolygon</code>
   *      , or <code>null</code> or an empty array to create the empty geometry.
   *      Elements may be empty <code>Polygon</code>s, but not <code>null</code>
   *      s. The polygons must conform to the assertions specified in the <A
   *      HREF="http://www.opengis.org/techno/specs.htm">OpenGIS Simple Features
   *      Specification for SQL</A> .
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>MultiPolygon</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>MultiPolygon</code>
   */
  public MultiPolygon(Polygon[] polygons, PrecisionModel precisionModel, int SRID) {
    super(polygons, precisionModel, SRID);
  }

  public int getDimension() {
    return 2;
  }

  public int getBoundaryDimension() {
    return 1;
  }

  public String getGeometryType() {
    return "MultiPolygon";
  }

  public boolean isSimple() {
    return true;
  }

  public Geometry getBoundary() {
    if (isEmpty()) {
      return new GeometryCollection(null, precisionModel, SRID);
    }
    ArrayList allRings = new ArrayList();
    for (int i = 0; i < geometries.length; i++) {
      Polygon polygon = (Polygon) geometries[i];
      GeometryCollection rings = (GeometryCollection) polygon.getBoundary();
      for (int j = 0; j < rings.getNumGeometries(); j++) {
        allRings.add(rings.getGeometryN(j));
      }
    }
    LineString[] allRingsArray = new LineString[allRings.size()];
    return new MultiLineString((LineString[]) allRings.toArray(allRingsArray),
        precisionModel, SRID);
  }

  public boolean equalsExact(Geometry other) {
    if (!isEquivalentClass(other)) {
      return false;
    }
    return super.equalsExact(other);
  }
}


