/*
 *  The Java Topology Suite (JTS) is a collection of Java classes that
 *  implement the fundamental operations required to validate a given
 *  geo-spatial data set to a known topological specification.
 *
 *  Copyright (C) 2001 Vivid Solutions
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  For more information, contact:
 *
 *  Vivid Solutions
 *  Suite #1A
 *  2328 Government Street
 *  Victoria BC  V8T 5G5
 *  Canada
 *
 *  (250)385-6040
 *  www.vividsolutions.com
 */

package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.geom.sfs.SFSMultiLineString;
import com.vividsolutions.jts.graph.GeometryGraph;

/**
 *  Basic implementation of <code>MultiLineString</code>.
 *
 *@version 1.0
 */
public class MultiLineString extends GeometryCollection implements SFSMultiLineString {

  /**
   *  Constructs a <code>MultiLineString</code>.
   *
   *@param  lineStrings     the <code>LineString</code>s for this <code>MultiLineString</code>
   *      , or <code>null</code> or an empty array to create the empty geometry.
   *      Elements may be empty <code>LineString</code>s, but not <code>null</code>
   *      s.
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>MultiLineString</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>MultiLineString</code>
   */
  public MultiLineString(LineString[] lineStrings, PrecisionModel precisionModel, int SRID) {
    super(lineStrings, precisionModel, SRID);
  }

  public int getDimension() {
    return 1;
  }

  public int getBoundaryDimension() {
    if (isClosed()) {
      return Dimension.FALSE;
    }
    return 0;
  }

  public String getGeometryType() {
    return "MultiLineString";
  }

  public boolean isClosed() {
    if (isEmpty()) {
      return false;
    }
    for (int i = 0; i < geometries.length; i++) {
      if (!((LineString) geometries[i]).isClosed()) {
        return false;
      }
    }
    return true;
  }

  public boolean isSimple() {
    throw new java.lang.UnsupportedOperationException("Method not yet implemented.");
  }

  public Geometry getBoundary() {
    if (isEmpty()) {
      return new GeometryCollection(null, precisionModel, SRID);
    }
    GeometryGraph g = new GeometryGraph(0, this);
    Coordinate[] pts = g.getBoundaryPoints();
    GeometryFactory fact = new GeometryFactory(precisionModel, SRID);
    return fact.createMultiPoint(pts);
  }

  public boolean equalsExact(Geometry other) {
    if (!isEquivalentClass(other)) {
      return false;
    }
    return super.equalsExact(other);
  }

}

