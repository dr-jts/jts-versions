

/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import com.vividsolutions.jts.geom.sfs.SFSLinearRing;


/**
 *  Basic implementation of <code>LinearRing</code>.
 *
 *@version 1.3
 */
public class LinearRing extends LineString
     implements SFSLinearRing {

  /**
   *  Constructs a <code>LinearRing</code> with the given points.
   *
   *@param  points          points forming a closed and simple linestring, or
   *      <code>null</code> or an empty array to create the empty geometry.
   *      This array must not contain <code>null</code> elements. Consecutive
   *      points may not be equal.
   *@param  precisionModel  the specification of the grid of allowable points
   *      for this <code>LinearRing</code>
   *@param  SRID            the ID of the Spatial Reference System used by this
   *      <code>LinearRing</code>
   */
  public LinearRing(Coordinate points[], PrecisionModel precisionModel,
      int SRID) {
    super(points, precisionModel, SRID);
    if (!isEmpty() && ! super.isClosed()) {
      throw new IllegalArgumentException("points must form a closed linestring");
    }
    if (points != null && (points.length >= 1 && points.length <= 3)) {
      throw new IllegalArgumentException("Number of points must be 0 or >3");
    }
  }

  public boolean isSimple() {
    return true;
  }

  public String getGeometryType() {
    return "LinearRing";
  }

  public boolean isClosed() {
    return true;
  }

  public Object clone() {
    LinearRing lr = (LinearRing) super.clone();
    return lr;// return the clone
  }

}

