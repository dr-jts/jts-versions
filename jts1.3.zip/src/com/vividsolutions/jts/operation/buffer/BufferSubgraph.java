

/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.buffer;

/**
 * @version 1.3
 */

import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.algorithm.*;
import com.vividsolutions.jts.graph.*;



/**
 * A BufferSubgraph is a connected subset of the graph of DirectedEdges and Nodes
 * in a BufferGraph.  Its edges will generate either
 * <ul>
 * <li> a single polygon in the complete buffer, with zero or more holes, or
 * <li> one or more connected holes
 * </ul>
 *
 */
public class BufferSubgraph
  implements Comparable
{
  private RightmostEdgeFinder finder;
  private List dirEdgeList  = new ArrayList();
  private List nodes        = new ArrayList();
  private Coordinate rightMostCoord = null;

  public BufferSubgraph(CGAlgorithms cga)
  {
    finder = new RightmostEdgeFinder(cga);
  }

  public List getDirectedEdges() { return dirEdgeList; }
  public List getNodes() { return nodes; }
  /**
   * Get the rightMost coordinate in the edges of the subgraph
   */
  public Coordinate getRightmostCoordinate()
  {
    return rightMostCoord;
  }

  public void create(Node node)
  {
    add(node);
    finder.findEdge(dirEdgeList);
    rightMostCoord = finder.getCoordinate();
  }
  private void add(Node node)
  {
    node.setVisited(true);
    nodes.add(node);
    for (Iterator i = ((DirectedEdgeStar) node.getEdges()).iterator(); i.hasNext(); ) {
      DirectedEdge de = (DirectedEdge) i.next();
      dirEdgeList.add(de);
      DirectedEdge sym = de.getSym();
      Node symNode = sym.getNode();
      /**
       * NOTE: this is a depth-first traversal of the graph.
       * This will cause a large depth of recursion.
       * It might be better to do a breadth-first traversal.
       */
      if (! symNode.isVisited()) add(symNode);
    }
  }

  private void clearVisitedEdges()
  {
    for (Iterator it = dirEdgeList.iterator(); it.hasNext(); ) {
      DirectedEdge de = (DirectedEdge) it.next();
      de.setVisited(false);
    }
  }

  public void computeDepth(int outsideDepth)
  {
    clearVisitedEdges();
    // find an outside edge to assign depth to
    DirectedEdge de = finder.getEdge();
    Node n = de.getNode();
    Label label = de.getLabel();
    // right side of line returned by finder is on the outside
    de.setEdgeDepths(Position.RIGHT, outsideDepth);

    computeNodeDepth(n, de);
  }

  private void computeNodeDepth(Node n, DirectedEdge startEdge)
  {
    if (startEdge.isVisited()) return;

    ((DirectedEdgeStar) n.getEdges()).computeDepths(startEdge);

    // copy depths to sym edges
    for (Iterator i = ((DirectedEdgeStar) n.getEdges()).iterator(); i.hasNext(); ) {
      DirectedEdge de = (DirectedEdge) i.next();
      de.setVisited(true);
      DirectedEdge sym = de.getSym();
      sym.setDepth(Position.LEFT, de.getDepth(Position.RIGHT));
      sym.setDepth(Position.RIGHT, de.getDepth(Position.LEFT));
    }
    // propagate depth to all linked nodes via the sym edges
    // If a sym edge has been visited already, there is no need to process it further
    for (Iterator i = ((DirectedEdgeStar) n.getEdges()).iterator(); i.hasNext(); ) {
      DirectedEdge de = (DirectedEdge) i.next();
      DirectedEdge sym = de.getSym();
      Node symNode = sym.getNode();
      /**
       * NOTE: this is a depth-first traversal of the graph.
       * This will cause a large depth of recursion.
       * It might be better to do a breadth-first traversal.
       */
      computeNodeDepth(symNode, sym);
    }

  }
  /**
   * Find all edges whose depths indicates that they are in the result area(s).
   * Since we want polygon shells to be
   * oriented CW, choose dirEdges with the interior of the result on the RHS.
   * Mark them as being in the result.
   * Interior Area edges are the result of dimensional collapses.
   * They do not form part of the result area boundary.
   */
  public void findResultEdges()
  {
    for (Iterator it = dirEdgeList.iterator(); it.hasNext(); ) {
      DirectedEdge de = (DirectedEdge) it.next();
      /**
       * Select edges which have the EXTERIOR on the L and INTERIOR
       * on the right.  It doesn't matter how deep the interior is.
       */
      if (    de.getDepth(Position.RIGHT) >= 1
          &&  de.getDepth(Position.LEFT)  == 0
          &&  ! de.isInteriorAreaEdge()) {
        de.setInResult(true);
//Debug.print("in result "); Debug.println(de);
      }
    }
  }

  /**
   * BufferSubgraphs are compared on the x-value of their rightmost Coordinate.
   * This defines a partial ordering on the graphs such that:
   * <p>
   * g1 >= g2 <==> Ring(g2) does not contain Ring(g1)
   * <p>
   * where Polygon(g) is the buffer polygon that is built from g.
   * <p>
   * This relationship is used to sort the BufferSubgraphs so that shells are guaranteed to
   * be built before holes.
   */
  public int compareTo(Object o) {
    BufferSubgraph graph = (BufferSubgraph) o;
    if (this.rightMostCoord.x < graph.rightMostCoord.x) {
      return -1;
    }
    if (this.rightMostCoord.x > graph.rightMostCoord.x) {
      return 1;
    }
    return 0;
  }


}
